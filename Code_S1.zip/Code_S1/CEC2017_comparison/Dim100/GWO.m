% �����Ż��㷨GWO
function [Best_fitness,Best_pos, Iter_curve]=GWO(pop, maxIter,lb,ub,dim,fobj)

%% ����Alpah�ǣ�Beta�ǣ�Delta��
Alpha_pos=zeros(1,dim);
Alpha_score=inf; 
Beta_pos=zeros(1,dim);
Beta_score=inf;
Delta_pos=zeros(1,dim);
Delta_score=inf; 
%% ��ʼ����Ⱥλ��
if size(lb,1)==1
    lb = lb.*ones(1,dim);
    ub = ub.*ones(1,dim);
end
Positions = zeros(pop, dim);
for i = 1:pop
    for j = 1:dim
        Positions(i,j) = (ub(j) - lb(j)) * rand() + lb(j);
    end
end
%% ��ʼ����Ӧ��ֵ
fitness = zeros(1,pop);
for i = 1:pop
    fitness(i) = fobj(Positions(i,:));
end
%% ��Ӧ������
[SortFitness, indexSort] = sort(fitness);
% Alpha��
Alpha_pos = Positions(indexSort(1),:);
Alpha_score = SortFitness(1);
% Beta��
Beta_pos = Positions(indexSort(2),:);
Beta_score = SortFitness(2);
% Delta��
Delta_pos = Positions(indexSort(3),:);
Delta_score = SortFitness(3);
gBest = Alpha_pos;
gBestFitness = Alpha_score;
%% ����
for t = 1:maxIter
    %��������a
    a = 2 - t*((2) / maxIter);
    for i = 1 :pop
        for j = 1:dim
            %����Alpha�Ǹ���λ��
            r1 = rand(); r2 = rand();
            A1 = 2 * a * r1 - a;
            C1 = 2 * r2;
            %������Alpha�ǵ�λ��
            D_alpha = abs(C1 * Alpha_pos(j) - Positions(i,j));
            X1 = Alpha_pos(j) - A1 * D_alpha;
            
            %����Beta�Ǹ���λ��
            r1 = rand(); r2 = rand();
            A2 = 2 * a * r1 - a;
            C2 = 2 * r2;
            %������Beta�ǵ�λ��
            D_beta= abs(C2 * Beta_pos(j) - Positions(i,j));
            X2 = Beta_pos(j) - A2 * D_beta; 
            
            %����Delta�Ǹ���λ��
            r1 = rand(); r2 = rand();
            A3 = 2 * a * r1 - a;
            C3 = 2 * r2;
            %������Delta�ǵ�λ��
            D_delta= abs(C3 * Delta_pos(j) - Positions(i,j));
            X3 = Delta_pos(j) - A3 * D_delta; 
            
            %����λ��
            Positions(i,j) = (X1 + X2 + X3) / 3;
        end
        
        %�߽���
        for k = 1:dim
            if Positions(i,k) > ub(k)
                Positions(i,k) = ub(k);
            end
            if Positions(i,k) < lb(k)
                Positions(i,k) = lb(k);
            end
        end
    end
    
    %������Ӧ��ֵ
    for i = 1:pop
        fitness(i) = fobj(Positions(i,:));
        % ����alpha��beta��delta��
        if fitness(i) < Alpha_score
            Alpha_score = fitness(i);
            Alpha_pos = Positions(i,:);
        end
        if fitness(i) > Alpha_score && fitness(i) < Beta_score
            Beta_score = fitness(i);
            Beta_pos = Positions(i,:);
        end
        if fitness(i) > Alpha_score && fitness(i) > Beta_score && fitness(i) < Delta_score
            Delta_score = fitness(i);
            Delta_pos = Positions(i,:);
        end
    end
    gBest = Alpha_pos;
    gBestFitness = Alpha_score;

    Iter_curve(t) = gBestFitness;
    
end
Best_pos = gBest;
Best_fitness = gBestFitness;
end
