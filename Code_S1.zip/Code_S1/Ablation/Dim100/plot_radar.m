clear,clc,close all

%% load data
data = xlsread('CEC2017测试结果.xlsx');
data = data(:,6);
data(isnan(data)) = [];
data(5:8) = []; %去掉F2


%% 绘图
X = reshape(data,4,[]);
RC=radarChart(X);
RC.PropName={'F1','F3','F4','F5','F6','F7','F8','F9','F10','F11','F12','F13','F14',...
    'F15','F16','F17','F18','F19','F20','F21','F22','F23','F24','F25','F26','F27','F28','F29','F30'};
RC.ClassName={'MSCCO\_wo1','MSCCO\_wo2','MSCCO\_wo3','MSCCO'};
RC=RC.draw();
RC.legend();



% RGB Matrix
colorList = [
        0.0000  0.4470  0.7410;   % blue
        0.8500  0.3250  0.0980;   % orange
        0.4660  0.6740  0.1880;   % green
        0.4940  0.1840  0.5560;   % purple
        0.9290  0.6940  0.1250;   % yellow
        0.3010  0.7450  0.9330;   % cyan
        0.6350  0.0780  0.1840;   % red
        0.2500  0.2500  0.2500;   % gray
        0.0000  0.6000  0.5000];  % teal
for n=1:RC.ClassNum
    RC.setPatchN(n,'Color',colorList(n,:),'MarkerFaceColor',colorList(n,:));
end


