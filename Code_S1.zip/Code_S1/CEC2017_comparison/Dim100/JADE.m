% JADE differential evolution
function [Best_fitness, Best_pos, Iter_curve] = JADE(pop, maxIter, lb, ub, dim, fobj)

lb = expand_bound(lb, dim);
ub = expand_bound(ub, dim);
c = 0.1;
p = 0.05;
muCR = 0.5;
muF = 0.5;

P = rand(pop, dim) .* (ub - lb) + lb;
fitness = zeros(pop, 1);
for i = 1:pop
    fitness(i) = fobj(P(i, :));
end
[Best_fitness, best_idx] = min(fitness);
Best_pos = P(best_idx, :);
archive = zeros(0, dim);
Iter_curve = zeros(1, maxIter);

for iter = 1:maxIter
    [~, sorted_idx] = sort(fitness, 'ascend');
    top = max(1, min(pop, ceil(p * pop)));
    CR = zeros(pop, 1);
    F = zeros(pop, 1);
    U = zeros(pop, dim);
    successfulCR = zeros(0, 1);
    successfulF = zeros(0, 1);

    for i = 1:pop
        CR(i) = min(1, max(0, muCR + 0.1 * randn));
        F(i) = muF + 0.1 * tan(pi * (rand - 0.5));
        while F(i) <= 0
            F(i) = muF + 0.1 * tan(pi * (rand - 0.5));
        end
        F(i) = min(F(i), 1);

        pbest_idx = sorted_idx(randi(top));
        r1 = randi(pop);
        while r1 == i
            r1 = randi(pop);
        end

        pool = [P; archive];
        r2 = randi(size(pool, 1));
        P1 = P(r1, :);
        P2 = pool(r2, :);
        mutant = P(i, :) + F(i) .* (P(pbest_idx, :) - P(i, :)) + F(i) .* (P1 - P2);

        jrand = randi(dim);
        mask = rand(1, dim) <= CR(i);
        mask(jrand) = true;
        U(i, :) = P(i, :);
        U(i, mask) = mutant(mask);
        U(i, :) = min(max(U(i, :), lb), ub);
    end

    trial_fitness = zeros(pop, 1);
    for i = 1:pop
        trial_fitness(i) = fobj(U(i, :));
        if trial_fitness(i) < fitness(i)
            archive(end + 1, :) = P(i, :); %#ok<AGROW>
            successfulCR(end + 1, 1) = CR(i); %#ok<AGROW>
            successfulF(end + 1, 1) = F(i); %#ok<AGROW>
            P(i, :) = U(i, :);
            fitness(i) = trial_fitness(i);
            if fitness(i) < Best_fitness
                Best_fitness = fitness(i);
                Best_pos = P(i, :);
            end
        end
    end

    if size(archive, 1) > pop
        archive = archive(randperm(size(archive, 1), pop), :);
    end
    if ~isempty(successfulCR)
        muCR = (1 - c) * muCR + c * mean(successfulCR);
        muF = (1 - c) * muF + c * sum(successfulF .^ 2) / sum(successfulF);
    end
    Iter_curve(iter) = Best_fitness;
end
end

function bound = expand_bound(bound, dim)
bound = bound(:)';
if numel(bound) == 1
    bound = repmat(bound, 1, dim);
elseif numel(bound) ~= dim
    error('Bounds must be scalars or vectors with length dim.');
end
end

