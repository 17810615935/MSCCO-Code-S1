% 侦探行为优化算法DBA
function [Best_Cost,Best_X,Convergence_curve]=DBA(nP,Max_It,lb,ub,dim,fobj)

%% Initialization
Convergence_curve=zeros(Max_It,1);


X = zeros(nP,dim);
pBest_X = zeros(nP,dim);  % Personal Best Position

Cost = zeros(nP,1);
pBest_Cost = zeros(nP,1);

X=initialization(nP,dim,ub,lb);

for i=1:nP
    pBest_X(i,:) = X(i,:);
	%Cost(i) =benchmark_func(X(i,:),fobj);
    Cost(i) = fobj(X(i,:));
    pBest_Cost(i) = Cost(i);
    
end

[Best_Cost,ind] = min(Cost);
Best_X = X(ind,:);
%k_exploration4=1;
%k_exploration1=1;k_exploration2=1;k_exploration3=1;% record the times 
%% Main Loop

for it=1:Max_It  
        
    for i=1:nP
        
        %judgement criterion for exploration and exploitation process:
        
        
        A=(10.0*rand-1)*sin(0.5*pi*it/Max_It);  
        if A>0.5
             if rand <0.5
                 X(i,:) = Best_X(1,:)-rand*(Best_X(1,:)-X(i,:));
                 %HisX1(k_exploration1,1:2)=X(i,1:2); k_exploration1=k_exploration1+1;% record the times 
             else
                 for j=1:dim
                     beta=1.5;
		             sigma1=gamma(1+beta)*sin(pi*beta/2)/(beta*gamma(0.5+0.5*beta)*2^(0.5*beta-0.5));
		             levy(j)=sigma1*randn/abs(randn)^(-beta);
                     X(i,j) = Best_X(1,j)+levy(j);
                 end
                 %HisX2(k_exploration2,1:2)=X(i,1:2); k_exploration2=k_exploration2+1;% record the times 
             end 
        else
            for j=1:dim
                if max(size(ub))>1
                      X(i,j) =(ub(j)+lb(j))*0.5+rand*(Best_X(1,j)-X(i,j));
                else
                     X(i,j) =(ub+lb)*0.5+rand*(Best_X(1,j)-X(i,j));
                end
            end  
            %HisX3(k_exploration3,1:2)=X(i,1:2); k_exploration3=k_exploration3+1;% record the times 
        end
        % Update Velocity
%         V(i,:) = W*V(i,:)+c1*rand(1,dim).*(pBest_X(i,:)-X(i,:)) ...
%                          +c2*rand(1,dim).*(Best_X-X(i,:));
        
        % Check Velocity Bounds
%           FU=V(i,:)>Vmax;FL=V(i,:)<Vmin;V(i,:)=(V(i,:).*(~(FU+FL)))+Vmax.*FU+Vmin.*FL;
%         
%         % Update Position
%          X(i,:) = X(i,:) + V(i,:);        
        
        % Check Position Bounds
          FU=X(i,:)>ub;FL=X(i,:)<lb;X(i,:)=(X(i,:).*(~(FU+FL)))+ub.*FU+lb.*FL;
         
          %Cost(i) =benchmark_func(X(i,:),fobj);
          Cost(i) = fobj(X(i,:));
          Opposite_X=(ub+lb)- X(i,:);
          if fobj(X(i,:))>fobj(Opposite_X)
          %if benchmark_func(X(i,:),fobj)>benchmark_func(Opposite_X,fobj)
               X(i,:)=Opposite_X;
               %Cost(i) =benchmark_func(X(i,:),fobj);
               %HisX4(k_exploration4,1:2)=X(i,1:2); k_exploration4=k_exploration4+1;% record the times 
               Cost(i) = fobj(X(i,:));
          end
        
        % decide additional variation or not: 
		X_new=X(i,:)+0.01.*(ub-lb).*randn(1,dim);
		
		FU=X_new>ub;FL=X_new<lb;X(i,:)=(X_new.*(~(FU+FL)))+ub.*FU+lb.*FL;
		Cost_new = fobj(X_new);
		if Cost(i)>Cost_new
		   X(i,:)=X_new; Cost(i) =Cost_new;
		end
        
        % Update Personal Best
        if Cost(i)<pBest_Cost(i)
            
            pBest_X(i,:) = X(i,:);
            pBest_Cost(i) = Cost(i);
            
            % Update Global Best
            if pBest_Cost(i)<Best_Cost
                Best_X = pBest_X(i,:);
                Best_Cost = pBest_Cost(i);
            end
            
        end
        
    end

    first_dimension(it,1)=Best_X(1,1);
    Convergence_curve(it)=Best_Cost;
	Average_curve(it,1)=sum(Cost)/max(size(Cost));

end




