%% 绘制路径
clear, clc, close all
root_dir = fileparts(mfilename('fullpath'));
addpath(root_dir);
result_dir = fullfile(root_dir, 'result');
old_visibility = get(groot, 'DefaultFigureVisible');
set(groot, 'DefaultFigureVisible', 'off');
try
    for sid = 1:4
        data = load(fullfile(result_dir, sprintf('scenario%d.mat', sid)));
        if isfield(data, 'model') && isfield(data, 'problem') && isfield(data, 'scene')
            model = data.model;
            problem = data.problem;
            scene = data.scene;
            assignment = data.assignment;
        else
            [model, problem, scene, assignment] = SetupScenario(sid, false, data.assignment);
        end
        ExportAlgorithmPaths(model, problem, scene, assignment, sid, ...
            data.algorithm_list, data.fit, data.pos, result_dir);
    end
catch ME
    set(groot, 'DefaultFigureVisible', old_visibility);
    rethrow(ME);
end
set(groot, 'DefaultFigureVisible', old_visibility);
