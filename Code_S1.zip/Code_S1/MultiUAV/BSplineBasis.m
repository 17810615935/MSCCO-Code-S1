%% 三次B样条基函数矩阵
function N = BSplineBasis(num_ctrl, degree, num_samples)

    p = min(degree, num_ctrl - 1);
    n = num_ctrl - 1;
    knots = [zeros(1, p), linspace(0, 1, n - p + 2), ones(1, p)];
    u = linspace(0, 1, num_samples)';

    num_basis0 = numel(knots) - 1;
    B = zeros(num_samples, num_basis0);
    for j = 1:num_basis0
        B(:, j) = (u >= knots(j)) & (u < knots(j+1));
    end
    last = find(knots < 1, 1, 'last');
    B(u == 1, :) = 0;
    B(u == 1, last) = 1;

    for k = 1:p
        num_basis = num_basis0 - k;
        Bk = zeros(num_samples, num_basis);
        for j = 1:num_basis
            d1 = knots(j+k) - knots(j);
            d2 = knots(j+k+1) - knots(j+1);
            t1 = 0;
            t2 = 0;
            if d1 > 0
                t1 = (u - knots(j)) / d1 .* B(:, j);
            end
            if d2 > 0
                t2 = (knots(j+k+1) - u) / d2 .* B(:, j+1);
            end
            Bk(:, j) = t1 + t2;
        end
        B = Bk;
    end

    N = B;
end
