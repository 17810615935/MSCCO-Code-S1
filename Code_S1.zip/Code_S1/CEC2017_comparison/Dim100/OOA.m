% 章鱼优化算法OOA
function [Best_fitness,Best_pos,Iter_curve]=OOA(pop,maxIter,lb,ub,dim,fobj)
%%%%%%%%%%%%%%%%%%%%%%%%%
methname='OOA Algorithm';
J = 1;
MaxIt = maxIter;
nPop = pop;
Dim = dim;
VarMin = lb(:)';
VarMax = ub(:)';
if numel(VarMin) == 1
    VarMin = repmat(VarMin, 1, Dim);
    VarMax = repmat(VarMax, 1, Dim);
end
fhd = @(x) fobj(reshape(x,1,[]));
VarSize=[1 Dim];   % Size of Decision Variables Matrix
pl=12;         % Safe mating distance threshold

wdamp=1.5;     % Setting the Fluid velocity damping coefficient

beta1=0.5;     % Perception coefficient of the octopus to potential prey
beta2=0.25;    % Perception coefficient of octopus to natural predator
beta3=0.75;    % Perception coefficient of octopus to prey

fai=0.75;      % Coefficient of the potential prey for attracting the octopus
u=1;         % Coefficient of the predator attracting the octopus
mu=2;        % Coefficient of the prey for attracting the octopus
it=1;
BestCost=zeros(MaxIt,1);
VelMax=0.1*(VarMax-VarMin);
VelMin=-VelMax;
%% Initialization
empty_particle.Position=[];
empty_particle.Cost=[];
empty_particle.Best.Cost=[];
empty_particle.Best.Position=[];
empty_particle.Velocity=[];
empty_particle.Velocity0=[];
particle=repmat(empty_particle,nPop,1);
GlobalBest.Cost=inf;
GlobalBest.Position=zeros(1,Dim);
%% Record
fitness_history=zeros(nPop,MaxIt);
position_history=zeros(nPop,MaxIt,Dim);
Trajectories=zeros(nPop,MaxIt);
Positions=initializationOOA(nPop,Dim,VarMax,VarMin);
for i=1:nPop
   particle(i).Position=Positions(i,:);
end
for i=1:nPop  
    
    % Initialize Velocity
    particle(i).Velocity=rand(VarSize).*ones(1,Dim);
    particle(i).Velocity0=0.0.*particle(i).Velocity;
    % Evaluation
    particle(i).Cost=feval(fhd,particle(i).Position');
    position_history(i,1,:)=particle(i).Position(:);
    fitness_history(i,1)=particle(i).Cost;
    Trajectories(i,1)=particle(i).Position(1);
    % Update Personal Best
    particle(i).Best.Position=particle(i).Position;
    particle(i).Best.Cost=particle(i).Cost;
    % Update Global Best
        % Update Global Best
    if particle(i).Best.Cost<GlobalBest.Cost
        GlobalBest=particle(i).Best;
    end    
end
GlobalBest;
GlobalBest.Cost;
GlobalBest.Position;
BestCost(1)=GlobalBest.Cost;
while it<=MaxIt
    a=2.*(1-it./MaxIt);%Time–varying parameter
    al = 5000*(it./MaxIt).^(1-sqrt(it./MaxIt)); %Recoil acceleration
    F=1./2.*wdamp.*(1-it./MaxIt).^(1-exp(-it./MaxIt)); %Fluid resistance coefficient

    for  i=1:nPop
        A=2*a*rand-a;%Stochastic selection/mode-switch parameter
        
        A1=rand().*2.^(u); %Strength of octopus excluding natural predator
        A2=rand().*2.^(mu); %Strength of prey attracting octopus
        A3=rand().*2.^(fai); %Strength of potential prey attracting octopus

       if  abs(A)>1
           if  rand>0.5%Searching for potential prey (perception-guided spatial scanning), JCDE- Equation 1 and Equation 2
            
            k0=randperm(nPop,1);
            r0=abs(particle(k0).Position-particle(i).Position);%
            ribest=abs(particle(i).Best.Position-particle(i).Position);
            particle(i).Velocity = F.*particle(i).Velocity ...
                +A1.*exp(-beta2.*r0.^(1./2).*(it./MaxIt)).*(particle(k0).Position-particle(i).Position) ...
            +A3.*exp(-beta1.*ribest.^(1./2).*(1-(it./MaxIt).^(1./2))).*(particle(i).Best.Position-particle(i).Position); 

        % Apply Velocity Limits
        particle(i).Velocity = max(particle(i).Velocity,VelMin);
        particle(i).Velocity = min(particle(i).Velocity,VelMax);
            
            particle(i).Position = particle(i).Position +particle(i).Velocity;
            particle(i).Velocity0=particle(i).Velocity;
               
           else %Avoiding natural enemies or predators (recoil-driven exclusion), JCDE- Equation 3 and Equation 4
               k=randperm(nPop,2);
    
    r1=abs(particle(k(1)).Position-particle(i).Position);
    r2=abs(particle(k(2)).Position-particle(i).Position);
    particle(i).Velocity = F.*particle(i).Velocity ...
            +A1.*exp(-beta2.*r1.^(1./2).*(it./MaxIt)).*(particle(k(1)).Position-particle(i).Position) ...
            +A1.*exp(-beta2.*r2.^(1./2).*(it./MaxIt)).*(particle(k(2)).Position-particle(i).Position); 

        % Apply Velocity Limits
        particle(i).Velocity = max(particle(i).Velocity,VelMin);
        particle(i).Velocity = min(particle(i).Velocity,VelMax);
        
        % Update Position
        particle(i).Position = particle(i).Position+particle(i).Velocity -abs(A).*((particle(i).Velocity).^2-(particle(i).Velocity0).^2)./(2.*al);
        particle(i).Velocity0=particle(i).Velocity;
    
           end
       else   %Attacking and preying on prey (directed acceleration toward high-quality areas), JCDE- Equation 5 and Equation 6
           
            ribest=abs(particle(i).Best.Position-particle(i).Position);
            rgbest=abs(GlobalBest.Position-particle(i).Position);
            particle(i).Velocity = F.*particle(i).Velocity ...
            +A3.*exp(-beta1.*ribest.^(1./2).*(1-(it./MaxIt).^(1./2))).*(particle(i).Best.Position-particle(i).Position) ...
            +A2.*exp(-beta3.*rgbest.^(1./2).*(1-it./MaxIt)).*(GlobalBest.Position-particle(i).Position); 

        % Apply Velocity Limits
        particle(i).Velocity = max(particle(i).Velocity,VelMin);
        particle(i).Velocity = min(particle(i).Velocity,VelMax);
        
        % Update Position
        particle(i).Position = particle(i).Position +particle(i).Velocity+abs(A).*((particle(i).Velocity).^2-(particle(i).Velocity0).^2)./(2.*al);
        particle(i).Velocity0=particle(i).Velocity;
           
       end
       % Velocity Mirror Effect
        IsOutside=(particle(i).Position<VarMin | particle(i).Position>VarMax);
        particle(i).Velocity(IsOutside)=-particle(i).Velocity(IsOutside);
        
        % Apply Position Limits
        particle(i).Position = max(particle(i).Position,VarMin);
        particle(i).Position = min(particle(i).Position,VarMax);
        
        % Evaluation
        particle(i).Cost = feval(fhd,particle(i).Position');

        % Update Personal Best
        if particle(i).Cost<particle(i).Best.Cost
            
            particle(i).Best.Position=particle(i).Position;
            particle(i).Best.Cost=particle(i).Cost;
            
            % Update Global Best
            if particle(i).Best.Cost<GlobalBest.Cost
                
                GlobalBest=particle(i).Best;

            end
 
        end

    end
    GlobalBest;
    GlobalBest.Cost;
    GlobalBest.Position;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Mating behavior%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     kk1 = randperm(nPop); % eqn 4 (in the paper: EAAI)
     kk2 = randperm(nPop); % eqn 5 (in the paper: EAAI)
     k1x= particle(kk1);%Male
     k2x= particle(kk2);%Female
     
     select =[kk1' kk2']; % nak cari yang <pl
     kurang_7 = abs(select(:,1)-select(:,2));
     id_int7 = find((kurang_7)>0 & (kurang_7)<=pl); %The "arms grasping" strategy 
     id_over7 = find((kurang_7)>pl);                %The "arms extending" strategy
     id_same = find((kurang_7)==0);                 %The "arms severing" strategy

     Sparticle=repmat(empty_particle,nPop,1);
     temp1particle=repmat(empty_particle,nPop,1);
     temp2particle=repmat(empty_particle,nPop,1);
    
     if id_int7~=0               %The "arms grasping" strategy (close-range exploitation)
         for kk=1:size(id_int7,1)
             for kkk=1:Dim
             p=randn(); 
             temp1particle(kk).Posotion(kkk)=p*k1x(id_int7(kk)).Position(kkk);
             temp2particle(kk).Posotion(kkk)=(1-p)*k2x(id_int7(kk)).Position(kkk); 
             Sparticle(id_int7(kk)).Position(kkk)=temp1particle(kk).Posotion(kkk)+temp2particle(kk).Posotion(kkk);%JCDE-Equation 7
             end
         % Apply Position Limits
         Sparticle(id_int7(kk)).Position = max(Sparticle(id_int7(kk)).Position,VarMin);
         Sparticle(id_int7(kk)).Position = min(Sparticle(id_int7(kk)).Position,VarMax);
         % Evaluation
         Sparticle(id_int7(kk)).Cost=feval(fhd,Sparticle(id_int7(kk)).Position');
          
         % Update Global Best
         if  Sparticle(id_int7(kk)).Cost<GlobalBest.Cost 
             GlobalBest=Sparticle(id_int7(kk));
             GlobalBest.Cost=Sparticle(id_int7(kk)).Cost;
             GlobalBest.Position=Sparticle(id_int7(kk)).Position;
         end
         Sparticle(id_int7(kk)).Velocity=zeros(VarSize);
         Sparticle(id_int7(kk)).Velocity0=zeros(VarSize);
         Sparticle(id_int7(kk)).Best.Position = Sparticle(id_int7(kk)).Position;
         Sparticle(id_int7(kk)).Best.Cost = Sparticle(id_int7(kk)).Cost;
         end
     end
     
     if id_over7~=0                 %The "arms extending" strategy (medium-range exploitation)
         for kkk1=1:size(id_over7,1)
             for kkkk1=1:Dim
                 temp3particle(kkk1).Position(kkkk1)=k2x(id_over7(kkk1)).Position(kkkk1);
                 temp4particle(kkk1).Position(kkkk1)=rand().*temp3particle(kkk1).Position(kkkk1); %JCDE-Equation 8
                 Sparticle(id_over7(kkk1)).Position(kkkk1)=temp4particle(kkk1).Position(kkkk1);
             end
         % Apply Position Limits
         Sparticle(id_over7(kkk1)).Position = max(Sparticle(id_over7(kkk1)).Position,VarMin);
         Sparticle(id_over7(kkk1)).Position = min(Sparticle(id_over7(kkk1)).Position,VarMax);
         % Evaluation
         Sparticle(id_over7(kkk1)).Cost=feval(fhd,Sparticle(id_over7(kkk1)).Position');

         % Update Global Best
         if  Sparticle(id_over7(kkk1)).Cost<GlobalBest.Cost 
             GlobalBest=Sparticle(id_over7(kkk1));
             GlobalBest.Cost=Sparticle(id_over7(kkk1)).Cost;
             GlobalBest.Position=Sparticle(id_over7(kkk1)).Position;
         end
         Sparticle(id_over7(kkk1)).Velocity=zeros(VarSize);
         Sparticle(id_over7(kkk1)).Velocity0=zeros(VarSize);
         Sparticle(id_over7(kkk1)).Best.Position = Sparticle(id_over7(kkk1)).Position;
         Sparticle(id_over7(kkk1)).Best.Cost = Sparticle(id_over7(kkk1)).Cost;
         end
     end

     if id_same~=0                 %The "arms severing" strategy (deep local exploitation intensification)
         for kkk2=1:size(id_same,1)
             for kkkk2=1:Dim
                 temp5particle(kkk2).Position(kkkk2)=k1x(id_same(kkk2)).Position(kkkk2);
                 temp6particle(kkk2).Position(kkkk2)=rand().*k2x(id_same(kkk2)).Position(kkkk2)+temp5particle(kkk2).Position(kkkk2); %JCDE-Equation 9
                 Sparticle(id_same(kkk2)).Position(kkkk2)=temp6particle(kkk2).Position(kkkk2);
             end
         % Apply Position Limits
         Sparticle(id_same(kkk2)).Position = max(Sparticle(id_same(kkk2)).Position,VarMin);
         Sparticle(id_same(kkk2)).Position = min(Sparticle(id_same(kkk2)).Position,VarMax);
         % Evaluation
         Sparticle(id_same(kkk2)).Cost=feval(fhd,Sparticle(id_same(kkk2)).Position');

         % Update Global Best
         if  Sparticle(id_same(kkk2)).Cost<GlobalBest.Cost 
             GlobalBest=Sparticle(id_same(kkk2));
             GlobalBest.Cost=Sparticle(id_same(kkk2)).Cost;
             GlobalBest.Position=Sparticle(id_same(kkk2)).Position;
         end
         Sparticle(id_same(kkk2)).Velocity=zeros(VarSize);
         Sparticle(id_same(kkk2)).Velocity0=zeros(VarSize);
         Sparticle(id_same(kkk2)).Best.Position = Sparticle(id_same(kkk2)).Position;
         Sparticle(id_same(kkk2)).Best.Cost = Sparticle(id_same(kkk2)).Cost;
         end
     end
     
     particle=[particle;Sparticle];
     [~,Sortindex]=sort([particle.Cost]);
     particle=particle(Sortindex);
     particle=particle(1:nPop);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     for i=1:nPop
         
         particle(i).Position=max(particle(i).Position,VarMin);
         particle(i).Position=min(particle(i).Position,VarMax);
         particle(i).Cost=feval(fhd,particle(i).Position');
         position_history(i,it,:)=particle(i).Position(:);
         fitness_history(i,it)=particle(i).Cost;
         Trajectories(:,it)=particle(i).Position(1);

         if particle(i).Cost<particle(i).Best.Cost
             particle(i).Best.Cost=particle(i).Cost;
             particle(i).Best.Position=particle(i).Position;
             if particle(i).Best.Cost<GlobalBest.Cost
            GlobalBest=particle(i).Best;
            GlobalBest.Cost=particle(i).Best.Cost;
            GlobalBest.Position=particle(i).Best.Position; 
             end
         end
         
     end
      
     GlobalBest;
     GlobalBest.Cost;
     BestCost(it)=GlobalBest.Cost;
    
     %disp([methname ' Running ' num2str(J)  ' on the ' num2str(varargin{:})  ' Function: OOA Iteration = ' num2str(it) ': Best Cost = ' num2str(BestCost(it))]);
     it=it+1; 
end
GlobalCost = GlobalBest.Cost;
GlobalPosition = GlobalBest.Position;
Best_fitness = GlobalCost;
Best_pos = GlobalPosition;
Iter_curve = reshape(BestCost, 1, []);
end




