function [best_fit, best_pos, curve] = RunAlgorithm(name, pop, maxIter, lb, ub, dim, fobj)

    fh = str2func(name);
    [o1, o2, curve] = fh(pop, maxIter, lb, ub, dim, fobj);
    if numel(o1) == 1
        best_fit = o1;
        best_pos = o2;
    else
        best_fit = o2;
        best_pos = o1;
    end
    best_pos = reshape(best_pos, 1, []);
    curve = reshape(curve, 1, []);
    if numel(curve) ~= maxIter
        error('%s返回的曲线长度为%d，应为%d。', name, numel(curve), maxIter);
    end
    curve = cummin(curve);
end
