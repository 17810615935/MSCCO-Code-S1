function [Best_fitness, Best_pos, Iter_curve] = MSCCO_wo3(pop, maxIter, lb, ub, dim, fobj)
% MSCCO_wo3：去除多样性更新；所有个体均执行 CCO 碰撞公式，保留策略1、策略2。

lb = expand_bound(lb, dim);
ub = expand_bound(ub, dim);


% 社会迁移的执行间隔与温度参数
social_interval = 15;  % 社会迁移执行间隔
T_max = 18;            % 初始采样温度
T_min = 0.2;           % 末期采样温度

% 初始化种群并计算个体适应度。
x = lb + rand(pop, dim) .* (ub - lb);
fitness = zeros(pop, 1);
for i = 1:pop
    fitness(i) = evaluate(fobj, x(i,:));
end
[Best_fitness, best_idx] = min(fitness);
Best_pos = x(best_idx,:);
Iter_curve = zeros(1, maxIter);

KP = randperm(pop, floor(pop / 2));

% 外部档案保存被当前种群淘汰的历史个体
archive = zeros(0, dim);
archive_fitness = zeros(0, 1);

for iter = 1:maxIter
    % 【策略1】中心碰撞自适应社会迁移策略：在 CCO 搜索前重组当前种群与历史档案
    if mod(iter, social_interval) == 0
        temperature = T_max - (T_max - T_min) * (iter / maxIter);
        [x, fitness, archive, archive_fitness] = social_restructuring(x, fitness, archive, archive_fitness, pop, temperature);
    end

    [fitness, order] = sort(fitness);
    x = x(order,:);
    parent = x;
    parent_fit = fitness;

    % 原始 CCO 种群质心。
    center = mean(parent, 1);
    ratio = (iter - 1) / max(1, maxIter - 1);
    eta = (1 - cos(pi * iter / maxIter)) / 2;

    % 根据当前种群协方差构造 PCA 碰撞空间，并保留原空间分组更新
    C = cov(parent(max(2, floor(pop / 2)):pop,:) - center);
    [basis, ~] = eig(C);
    xpca = parent * basis;
    in_pca = false(pop, 1);
    in_pca(KP) = true;

    candidates = parent;
    % 原始 CCO：不判断多样性，全部个体按原空间/PCA 分组更新。
    for i = 1:pop
        alpha = (cos(ratio * pi) + 1) / 3 + 0.2;
        mask = rand(1, dim) > alpha;
        r = rand;
        if in_pca(i)
            source = xpca;
        else
            source = parent;
        end
        % 原始 CCO 碰撞公式：两个差分项共用 ic，权重为 r 和 1-r。
        ia = randi(i);
        ic = randi(i);
        ib = randi(pop);
        id = randi(pop);
        candidates(i,:) = mask .* source(ia,:) + (1-mask) .* ...
            (alpha * source(i,:) + (1-alpha) * source(ic,:) + ...
            r * (source(ic,:) - source(ib,:)) + ...
            (1-r) * (source(ic,:) - source(id,:)));
        if in_pca(i)
            candidates(i,:) = candidates(i,:) * basis';
        end
        candidates(i,:) = random_repair(candidates(i,:), lb, ub);
    end

    % 【策略2】碰撞引导精英曲面搜索策略
    quadratic = parent;
    for i = 1:pop
        if i == 1
            peers = randperm(pop-1, 2) + 1;
            anchors = [1, peers];
        else
            peers = setdiff(2:pop, i);
            anchors = [1, i, peers(randi(numel(peers)))];
        end
        quadratic(i,:) = quadratic_point(parent(anchors,:), ...
            parent_fit(anchors), parent(i,:), lb, ub);
    end
    trial = clip_bound((1-eta) * candidates + eta * quadratic, lb, ub);

    for i = 1:pop
        trial_fit = evaluate(fobj, trial(i,:));
        chosen_pos = trial(i,:);
        chosen_fit = trial_fit;
        if chosen_fit < parent_fit(i)
            archive(end+1,:) = parent(i,:); 
            archive_fitness(end+1,1) = parent_fit(i);
            x(i,:) = chosen_pos;
            fitness(i) = chosen_fit;
        else
            x(i,:) = parent(i,:);
            fitness(i) = parent_fit(i);
        end
    end

    % 限制外部档案规模，保留有限的历史搜索信息
    if size(archive,1) > pop
        keep = randperm(size(archive,1), pop);
        archive = archive(keep,:);
        archive_fitness = archive_fitness(keep);
    end

    success_pca = sum(in_pca & fitness < parent_fit);
    success_original = sum(~in_pca & fitness < parent_fit);
    K = (success_pca + 1) / (success_pca + 1 + success_original + 1);
    K = min(0.7, max(0.3, K));
    KP = randperm(pop, min(pop-1, max(1, round(K * pop))));

    [current_best, best_idx] = min(fitness);
    if current_best < Best_fitness
        Best_fitness = current_best;
        Best_pos = x(best_idx,:);
    end
    Iter_curve(iter) = Best_fitness;
end
end

function [new_pop, new_fitness, new_archive, new_archive_fitness] = social_restructuring(pop, fitness, archive, archive_fitness, NP, temperature)
% 中心碰撞自适应社会迁移策略
if isempty(archive)
    combined_pop = pop;
    combined_fitness = fitness;
else
    combined_pop = [pop; archive];
    combined_fitness = [fitness; archive_fitness];
end

[unique_pop, ia, ~] = unique(combined_pop, 'rows', 'stable');
unique_fitness = combined_fitness(ia);
M = size(unique_pop, 1);

if M == 1
    new_pop = repmat(unique_pop, NP, 1);
    new_fitness = repmat(unique_fitness, NP, 1);
    new_archive = zeros(0, size(pop,2));
    new_archive_fitness = zeros(0,1);
    return;
end

mu = mean(unique_fitness);
sigma = std(unique_fitness);
if sigma <= eps || ~isfinite(sigma)
    sigma = 1;
end
normalized = (unique_fitness - mu) / sigma;
temperature = max(temperature, eps);
log_prob = -normalized / temperature;
log_prob = log_prob - max(log_prob);
prob = exp(log_prob);
prob = prob / sum(prob);

new_pop = zeros(NP, size(pop,2));
new_fitness = zeros(NP,1);
[~, best_idx] = min(unique_fitness);
new_pop(1,:) = unique_pop(best_idx,:);
new_fitness(1) = unique_fitness(best_idx);
selected = best_idx;

for i = 2:NP
    idx = roulette_index(prob);
    new_pop(i,:) = unique_pop(idx,:);
    new_fitness(i) = unique_fitness(idx);
    selected(end+1) = idx; 
end

not_selected = setdiff(1:M, unique(selected));
if isempty(not_selected)
    new_archive = zeros(0, size(pop,2));
    new_archive_fitness = zeros(0,1);
else
    new_archive = unique_pop(not_selected,:);
    new_archive_fitness = unique_fitness(not_selected);
    if size(new_archive,1) > NP
        [~, order] = sort(new_archive_fitness, 'descend');
        remove = order(1:size(new_archive,1)-NP);
        new_archive(remove,:) = [];
        new_archive_fitness(remove) = [];
    end
end
end

function idx = roulette_index(prob)
idx = find(cumsum(prob) >= rand, 1, 'first');
if isempty(idx)
    idx = numel(prob);
end
end

function q = quadratic_point(points, fit, fallback, lb, ub)
% 碰撞引导精英曲面搜索
span = ub-lb;
scale = span;
scale(scale == 0) = 1;
z = (points-lb) ./ scale + rand/1e5;
fit = fit-min(fit);
fscale = max(abs(fit));
q = fallback;
if ~isfinite(fscale) || fscale == 0
    return;
end
fit = fit/fscale;
z1 = z(1,:); z2 = z(2,:); z3 = z(3,:);
numerator = (z2.^2-z3.^2)*fit(1) + (z3.^2-z1.^2)*fit(2) + (z1.^2-z2.^2)*fit(3);
denominator = 2*((z2-z3)*fit(1) + (z3-z1)*fit(2) + (z1-z2)*fit(3));
valid = abs(denominator) > 64*eps & span > 0;
vertex = zeros(size(span));
vertex(valid) = numerator(valid) ./ denominator(valid);
valid = valid & isfinite(vertex) & vertex >= 0 & vertex <= 1;
q(valid) = lb(valid) + span(valid) .* vertex(valid);
end

function bound = expand_bound(bound, dim)
validateattributes(bound, {'numeric'}, {'real','finite','nonempty','vector'});
bound = bound(:)';
if isscalar(bound)
    bound = repmat(bound, 1, dim);
elseif numel(bound) ~= dim
    error('MSCCO_wo3:Bounds', 'Bounds must be scalars or vectors of length dim.');
end
end

function x = random_repair(x, lb, ub)
mask = ~isfinite(x) | x < lb | x > ub;
x(mask) = lb(mask) + rand(1,nnz(mask)) .* (ub(mask)-lb(mask));
end

function x = clip_bound(x, lb, ub)
x = min(max(x, lb), ub);
mask = ~isfinite(x);
if any(mask(:))
    midpoint = repmat((lb+ub)/2, size(x,1), 1);
    x(mask) = midpoint(mask);
end
end

function f = evaluate(fobj, x)
f = fobj(x);
end
