%% 仅重绘 MSCCO / PSO 路径图（等大正方形坐标轴、三维与俯视对齐）
clearvars
close all
root_dir = fileparts(mfilename('fullpath'));
addpath(root_dir);
result_dir = fullfile(root_dir, 'result');
out_dir = fullfile(root_dir, 'result', 'aligned_mscco_pso');
if ~exist(out_dir, 'dir')
    mkdir(out_dir);
end

old_visibility = get(groot, 'DefaultFigureVisible');
set(groot, 'DefaultFigureVisible', 'off');
keep_algs = {'MSCCO', 'PSO'};
try
    for sid = 1:4
        data = load(fullfile(result_dir, sprintf('scenario%d.mat', sid)));
        if isfield(data, 'model') && isfield(data, 'problem') && isfield(data, 'scene')
            model = data.model;
            problem = data.problem;
            scene = data.scene;
            assignment = data.assignment;
        else
            [model, problem, scene, assignment] = SetupScenario(sid, false, data.assignment);
        end
        idx = zeros(1, numel(keep_algs));
        for k = 1:numel(keep_algs)
            hit = find(strcmp(data.algorithm_list, keep_algs{k}), 1);
            assert(~isempty(hit), '场景%d缺少算法%s。', sid, keep_algs{k});
            idx(k) = hit;
        end
        ExportAlgorithmPaths(model, problem, scene, assignment, sid, ...
            data.algorithm_list(idx), data.fit(:, idx), data.pos(:, idx), out_dir);
    end
catch ME
    set(groot, 'DefaultFigureVisible', old_visibility);
    rethrow(ME);
end
set(groot, 'DefaultFigureVisible', old_visibility);
fprintf('Aligned path figures written to %s\n', out_dir);
