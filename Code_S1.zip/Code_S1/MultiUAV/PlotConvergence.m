%% 收敛曲线
function fig = PlotConvergence(curves, names, title_text)

    num_alg = numel(names);
    maxIter = size(curves, 2);
    colors = [
        0.0000  0.4470  0.7410;
        0.8500  0.3250  0.0980;
        0.4660  0.6740  0.1880;
        0.4940  0.1840  0.5560;
        0.9290  0.6940  0.1250;
        0.3010  0.7450  0.9330;
        0.2500  0.2500  0.2500;
        0.0000  0.6000  0.5000;
        0.6000  0.4000  0.2000;
        0.5500  0.5500  0.9000;
    ];
    markers = {'o','s','^','d','v','p','h','>','<','x','*'};
    step = max(1, floor(maxIter / 15));

    fig = figure('Name', title_text, 'Position', [150, 150, 640, 480], 'Color', 'w');
    h = gobjects(1, num_alg);
    for a = 1:num_alg
        if a == num_alg
            c = [0.85, 0.05, 0.05];
            lw = 2.2;
        else
            c = colors(mod(a-1, size(colors, 1)) + 1, :);
            lw = 1.4;
        end
        h(a) = semilogy(curves(a, :), 'Color', c, 'LineWidth', lw, ...
            'Marker', markers{mod(a-1, numel(markers)) + 1}, 'MarkerSize', 6, ...
            'MarkerIndices', 1:step:maxIter, 'MarkerFaceColor', c, ...
            'MarkerEdgeColor', c * 0.7);
        hold on;
    end
    hold off;
    xlabel('Iteration', 'FontName', 'Times New Roman', 'FontSize', 12);
    ylabel('Fitness Value', 'FontName', 'Times New Roman', 'FontSize', 12);
    title(title_text, 'FontName', 'Times New Roman', 'FontSize', 12, 'FontWeight', 'normal');
    legend(h, names, 'Interpreter', 'none', 'FontName', 'Times New Roman', ...
        'FontSize', 9, 'Location', 'northeast', 'NumColumns', 2);
    set(gca, 'FontName', 'Times New Roman', 'FontSize', 10, 'LineWidth', 1.0, ...
        'Box', 'on', 'XGrid', 'on', 'YGrid', 'on', 'GridLineStyle', ':', 'GridAlpha', 0.3);
end
