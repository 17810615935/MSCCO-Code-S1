% 中心碰撞优化算法 CCO
function [Best_fitness, Best_pos, Iter_curve] = CCO(pop, maxIter, lb, ub, dim, fobj)

lb = expand_bound(lb, dim);
ub = expand_bound(ub, dim);

x = initialization(pop, dim, ub, lb);
x_new = zeros(pop, dim);
fitness = zeros(pop, 1);
fitness_new = zeros(pop, 1);

for i = 1:pop
    fitness(i) = fobj(x(i, :));
end
[fbest, order] = sort(fitness);
fbest = fbest(1);
x = x(order, :);
fitness = fitness(order);
sbest = x(1, :);

K = 0.5;
KP = randperm(pop, max(1, floor(pop / 2)));
Iter_curve = zeros(1, maxIter);

for iter = 1:maxIter
    iter_ratio = (iter - 1) / max(1, maxIter - 1);
    x_mean = mean(x, 1);
    x_c = x - x_mean;

    if pop > 2
        C = cov(x_c(max(2, floor(pop / 2)):pop, :));
        [V, ~] = eig(C);
    else
        V = eye(dim);
    end
    x_pca = x * V;

    a1 = 1;
    a2 = 1;
    for j = 1:pop
        U = rand(1, dim);
        alpha = (cos(iter_ratio * pi) + 1) / 3 + 0.2;
        U = U > alpha;
        r = rand;
        r1 = alpha;

        if ismember(j, KP)
            ia = randi(j);
            ic = randi(j);
            ib = randi(pop);
            id = randi(pop);
            x_new_pca = U .* x_pca(ia, :) + (1 - U) .* ...
                (x_pca(j, :) * r1 + x_pca(ic, :) * (1 - r1) + ...
                r .* (x_pca(ic, :) - x_pca(ib, :)) + ...
                (1 - r) .* (x_pca(ic, :) - x_pca(id, :)));
            x_new(j, :) = x_new_pca * V';
        else
            ia = randi(j);
            ic = randi(j);
            ib = randi(pop);
            id = randi(pop);
            x_new(j, :) = U .* x(ia, :) + (1 - U) .* ...
                (x(j, :) * r1 + x(ic, :) * (1 - r1) + ...
                r .* (x(ic, :) - x(ib, :)) + ...
                (1 - r) .* (x(ic, :) - x(id, :)));
        end

        x_new(j, :) = random_repair(x_new(j, :), lb, ub);
        fitness_new(j) = fobj(x_new(j, :));

        if fitness_new(j) < fitness(j)
            x(j, :) = x_new(j, :);
            fitness(j) = fitness_new(j);
            if ismember(j, KP)
                a1 = a1 + 1;
            else
                a2 = a2 + 1;
            end
        end

        if fitness_new(j) < fbest
            fbest = fitness_new(j);
            sbest = x_new(j, :);
        end
    end

    denominator = a1 / K + a2 / (1 - K);
    if denominator > 0
        K = (a1 / K) / denominator;
    end
    K = min(0.7, max(0.3, K));
    kp = max(1, min(pop, round(K * pop)));
    KP = randperm(pop, kp);

    [fitness, order] = sort(fitness);
    x = x(order, :);
    if fitness(1) < fbest
        fbest = fitness(1);
        sbest = x(1, :);
    end
    Iter_curve(iter) = fbest;
end

Best_fitness = fbest;
Best_pos = sbest;
end

function bound = expand_bound(bound, dim)
bound = bound(:)';
if numel(bound) == 1
    bound = repmat(bound, 1, dim);
elseif numel(bound) ~= dim
    error('Bounds must be scalars or vectors with length dim.');
end
end

function x = random_repair(x, lb, ub)
mask = x < lb | x > ub | ~isfinite(x);
x(mask) = lb(mask) + rand(1, nnz(mask)) .* (ub(mask) - lb(mask));
end

function Positions = initialization(SearchAgents_no, dim, ub, lb)
Positions = rand(SearchAgents_no, dim) .* (ub - lb) + lb;
end

