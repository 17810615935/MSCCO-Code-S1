% 3架无人机，6个仓库点，3个配送点，每类威胁区2个
function [num_uavs, distribution_center, warehouses, delivery_points, no_fly_zones, em_zones, weather_zones] = Scenario2()

    num_uavs = 3;

    %% 固定配送中心
    distribution_center.id = 1;
    distribution_center.position = [30, 30, 31];
    distribution_center.type = 'distribution_center';

    %% 固定仓库点
    warehouse_data = [
        95, 320, 31;
        280, 470, 28;
        380, 320, 34;
        250, 120, 30;
        35, 335, 33;
        425, 250, 29;
    ];
    warehouses = CreatePoints(warehouse_data, 'warehouse');

    %% 固定配送点
    delivery_data = [
        470, 470, 38;
        470, 250, 34;
        250, 470, 36;
    ];
    delivery_points = CreatePoints(delivery_data, 'delivery');

    %% 固定威胁区
    % 空中禁飞区 [cx, cy, cz, radius]
    no_fly_zones = [
        75, 255, 67, 13;
        185, 320, 66, 12;
    ];

    % 电磁威胁区 [cx, cy, radius, z_max]
    em_zones = [
        135, 285, 27, 76;
        215, 115, 30, 84;
    ];

    % 恶劣天气区 [cx, cy, radius]
    weather_zones = [
        90, 90, 30;
        90, 410, 28;
    ];

    fprintf('\n=== 场景2 ===\n');
    fprintf('无人机: %d架\n', num_uavs);
    fprintf('仓库点: %d个\n', length(warehouses));
    fprintf('配送点: %d个\n', length(delivery_points));
    fprintf('每类威胁区: %d个\n', size(no_fly_zones, 1));
end

function points = CreatePoints(point_data, point_type)
    points = struct();
    for i = 1:size(point_data, 1)
        points(i).id = i;
        points(i).position = point_data(i, :);
        points(i).type = point_type;
    end
end
