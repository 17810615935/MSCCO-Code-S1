%% ALNS任务分配
function [assignment, curve] = ALNS_TaskAllocation(model, distribution_center, warehouses, delivery_points, num_uavs, params)

    Nw = numel(warehouses);
    Nd = numel(delivery_points);
    if Nd < num_uavs
        error('配送点数量不能少于无人机数量。');
    end

    W = reshape([warehouses.position], 3, [])';
    E = reshape([delivery_points.position], 3, [])';
    nodes = [distribution_center.position; W; E];
    Dist = ThreatAwareDistance(nodes, model, params.threat_factor);

    cap = max(params.min_cap, ceil(Nw / num_uavs));
    beta = params.balance_weight;
    end_perms = perms(1:Nd);
    end_perms = unique(end_perms(:, 1:num_uavs), 'rows');

    destroy_ops = {@DestroyRandom, @DestroyWorst, @DestroyShaw};
    repair_ops = {@RepairGreedy, @RepairRegret};
    w_d = ones(1, numel(destroy_ops));
    w_r = ones(1, numel(repair_ops));
    score_d = zeros(size(w_d));
    score_r = zeros(size(w_r));
    use_d = zeros(size(w_d));
    use_r = zeros(size(w_r));

    sol.routes = cell(num_uavs, 1);
    sol.ends = 1:num_uavs;
    sol = RepairGreedy(sol, 1:Nw);
    sol = Refine(sol);
    current = sol;
    best = sol;

    T = -params.start_ratio * best.cost / log(0.5);
    T_end = -params.end_ratio * best.cost / log(0.5);
    alpha = (T_end / T)^(1 / params.maxIter);

    curve = zeros(1, params.maxIter);
    max_remove = max(1, round(params.remove_ratio * Nw));

    for it = 1:params.maxIter
        id = Roulette(w_d);
        ir = Roulette(w_r);
        use_d(id) = use_d(id) + 1;
        use_r(ir) = use_r(ir) + 1;

        k = randi([1, max_remove]);
        [partial, removed] = destroy_ops{id}(current, k);
        candidate = repair_ops{ir}(partial, removed);
        candidate = Refine(candidate);

        gain = 0;
        if candidate.cost < best.cost - 1e-9
            best = candidate;
            current = candidate;
            gain = params.sigma(1);
        elseif candidate.cost < current.cost - 1e-9
            current = candidate;
            gain = params.sigma(2);
        elseif rand < exp(-(candidate.cost - current.cost) / T)
            current = candidate;
            gain = params.sigma(3);
        end
        score_d(id) = score_d(id) + gain;
        score_r(ir) = score_r(ir) + gain;

        if mod(it, params.segment) == 0
            used = use_d > 0;
            w_d(used) = (1 - params.reaction) * w_d(used) + params.reaction * score_d(used) ./ use_d(used);
            used = use_r > 0;
            w_r(used) = (1 - params.reaction) * w_r(used) + params.reaction * score_r(used) ./ use_r(used);
            w_d = max(w_d, 0.05);
            w_r = max(w_r, 0.05);
            score_d(:) = 0;
            score_r(:) = 0;
            use_d(:) = 0;
            use_r(:) = 0;
        end

        T = T * alpha;
        curve(it) = best.cost;
    end

    assignment.routes = best.routes;
    assignment.ends = best.ends;
    assignment.route_length = RouteCosts(best.routes, best.ends);
    assignment.cost = best.cost;
    assignment.total_length = sum(assignment.route_length);
    assignment.cap = cap;

    function c = RouteCost(route, e)
        seq = [1, route(:)' + 1, 1 + Nw + e];
        c = sum(Dist(sub2ind(size(Dist), seq(1:end-1), seq(2:end))));
    end

    function c = RouteCosts(routes, ends)
        c = zeros(num_uavs, 1);
        for u = 1:num_uavs
            c(u) = RouteCost(routes{u}, ends(u));
        end
    end

    function f = Objective(c)
        f = sum(c) + beta * max(c);
    end

    function s = Evaluate(s)
        s.route_cost = RouteCosts(s.routes, s.ends);
        s.cost = Objective(s.route_cost);
    end

    function [s, removed] = DestroyRandom(s, k)
        assigned = [s.routes{:}];
        k = min(k, numel(assigned));
        removed = assigned(randperm(numel(assigned), k));
        s = RemoveTasks(s, removed);
    end

    function [s, removed] = DestroyWorst(s, k)
        removed = [];
        for r = 1:k
            assigned = [s.routes{:}];
            if isempty(assigned)
                break;
            end
            gains = zeros(size(assigned));
            for j = 1:numel(assigned)
                u = FindRoute(s, assigned(j));
                route = s.routes{u};
                gains(j) = RouteCost(route, s.ends(u)) - ...
                    RouteCost(route(route ~= assigned(j)), s.ends(u));
            end
            [~, order] = sort(gains, 'descend');
            pick = order(min(numel(order), 1 + floor(rand^params.p_worst * numel(order))));
            removed(end+1) = assigned(pick);
            s = RemoveTasks(s, assigned(pick));
        end
    end

    function [s, removed] = DestroyShaw(s, k)
        assigned = [s.routes{:}];
        k = min(k, numel(assigned));
        seed = assigned(randi(numel(assigned)));
        removed = seed;
        pool = setdiff(assigned, seed);
        while numel(removed) < k && ~isempty(pool)
            ref = removed(randi(numel(removed)));
            rel = Dist(ref + 1, pool + 1);
            [~, order] = sort(rel);
            pick = order(min(numel(order), 1 + floor(rand^params.p_shaw * numel(order))));
            removed(end+1) = pool(pick);
            pool(pick) = [];
        end
        s = RemoveTasks(s, removed);
    end

    function s = RemoveTasks(s, tasks)
        for u = 1:num_uavs
            s.routes{u} = s.routes{u}(~ismember(s.routes{u}, tasks));
        end
    end

    function u = FindRoute(s, task)
        for u = 1:num_uavs
            if any(s.routes{u} == task)
                return;
            end
        end
        u = 0;
    end

    function s = RepairGreedy(s, removed)
        removed = removed(randperm(numel(removed)));
        for j = 1:numel(removed)
            [cost_u, pos_u] = InsertionCosts(s, removed(j));
            [~, u] = min(cost_u);
            s = InsertAt(s, removed(j), u, pos_u(u));
        end
        s = Evaluate(s);
    end

    function s = RepairRegret(s, removed)
        pending = removed;
        while ~isempty(pending)
            regret = -Inf(size(pending));
            best_u = zeros(size(pending));
            best_p = zeros(size(pending));
            best_c = Inf(size(pending));
            for j = 1:numel(pending)
                [cost_u, pos_u] = InsertionCosts(s, pending(j));
                [sorted_c, order] = sort(cost_u);
                best_u(j) = order(1);
                best_p(j) = pos_u(order(1));
                best_c(j) = sorted_c(1);
                if numel(sorted_c) > 1
                    regret(j) = sorted_c(2) - sorted_c(1);
                else
                    regret(j) = 0;
                end
            end
            regret(isnan(regret)) = Inf;
            cand = find(regret == max(regret));
            [~, m] = min(best_c(cand));
            j = cand(m);
            s = InsertAt(s, pending(j), best_u(j), best_p(j));
            pending(j) = [];
        end
        s = Evaluate(s);
    end

    function [cost_u, pos_u] = InsertionCosts(s, task)
        base = RouteCosts(s.routes, s.ends);
        cost_u = Inf(num_uavs, 1);
        pos_u = ones(num_uavs, 1);
        for u = 1:num_uavs
            route = s.routes{u};
            if numel(route) >= cap
                continue;
            end
            for p = 1:numel(route) + 1
                trial = [route(1:p-1), task, route(p:end)];
                c = base;
                c(u) = RouteCost(trial, s.ends(u));
                f = Objective(c);
                if f < cost_u(u)
                    cost_u(u) = f;
                    pos_u(u) = p;
                end
            end
        end
    end

    function s = InsertAt(s, task, u, p)
        route = s.routes{u};
        s.routes{u} = [route(1:p-1), task, route(p:end)];
    end

    function s = Refine(s)
        for u = 1:num_uavs
            s.routes{u} = BestOrder(s.routes{u}, s.ends(u));
        end
        len = zeros(num_uavs, Nd);
        for u = 1:num_uavs
            for e = 1:Nd
                len(u, e) = RouteCost(s.routes{u}, e);
            end
        end
        best_f = Inf;
        for r = 1:size(end_perms, 1)
            c = len(sub2ind(size(len), 1:num_uavs, end_perms(r, :)))';
            f = Objective(c);
            if f < best_f
                best_f = f;
                s.ends = end_perms(r, :);
            end
        end
        for u = 1:num_uavs
            s.routes{u} = BestOrder(s.routes{u}, s.ends(u));
        end
        s = Evaluate(s);
    end

    function route = BestOrder(route, e)
        n = numel(route);
        if n < 2
            return;
        end
        if n <= 6
            P = perms(route);
            best_c = Inf;
            for r = 1:size(P, 1)
                c = RouteCost(P(r, :), e);
                if c < best_c
                    best_c = c;
                    route = P(r, :);
                end
            end
        else
            improved = true;
            while improved
                improved = false;
                best_c = RouteCost(route, e);
                for i = 1:n-1
                    for j = i+1:n
                        trial = route;
                        trial(i:j) = route(j:-1:i);
                        c = RouteCost(trial, e);
                        if c < best_c - 1e-9
                            route = trial;
                            best_c = c;
                            improved = true;
                        end
                    end
                end
            end
        end
    end
end

function idx = Roulette(w)
    idx = find(cumsum(w) / sum(w) >= rand, 1, 'first');
    if isempty(idx)
        idx = numel(w);
    end
end

function Dist = ThreatAwareDistance(nodes, model, factor)
    n = size(nodes, 1);
    Dist = zeros(n);
    t = linspace(0, 1, 60)';
    for i = 1:n-1
        for j = i+1:n
            P = nodes(i, :) + t .* (nodes(j, :) - nodes(i, :));
            blocked = false(size(t));
            for k = 1:size(model.weather_zones, 1)
                r = model.weather_zones(k, 3) + model.D + model.S;
                blocked = blocked | sum((P(:, 1:2) - model.weather_zones(k, 1:2)).^2, 2) <= r^2;
            end
            for k = 1:size(model.em_zones, 1)
                r = model.em_zones(k, 3) + model.D + model.S;
                blocked = blocked | sum((P(:, 1:2) - model.em_zones(k, 1:2)).^2, 2) <= r^2;
            end
            for k = 1:size(model.no_fly_zones, 1)
                r = model.no_fly_zones(k, 4) + model.D + model.S;
                blocked = blocked | sum((P(:, 1:2) - model.no_fly_zones(k, 1:2)).^2, 2) <= r^2;
            end
            for k = 1:size(model.buildings, 1)
                b = model.box_min(k, :);
                c = model.box_max(k, :);
                blocked = blocked | (P(:, 1) >= b(1) & P(:, 1) <= c(1) & ...
                    P(:, 2) >= b(2) & P(:, 2) <= c(2));
            end
            d = norm(nodes(j, :) - nodes(i, :));
            Dist(i, j) = d * (1 + factor * mean(blocked));
            Dist(j, i) = Dist(i, j);
        end
    end
end
