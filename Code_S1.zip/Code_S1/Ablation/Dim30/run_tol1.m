clear,clc,close all
rootDir = fileparts(mfilename('fullpath'));
cd(rootDir);
addpath(rootDir);
rng_list = ones(1,30);

%% 删除现有Excel文件
excel_files = {'CEC2017测试结果.xlsx', 'CEC2017_时间成本对比.xlsx', ...
               'CEC2017_时间成本详细统计.xlsx', 'CEC2017_Wilcoxon秩和检验P值.xlsx', ...
               'CEC2017_Wilcoxon综合对比表.xlsx', 'CEC2017_算法Friedman排名.xlsx'};

for i = 1:length(excel_files)
    if exist(excel_files{i}, 'file')
        delete(excel_files{i});
        fprintf('已删除文件: %s\n', excel_files{i});
    end
end
%% 初始化结果存储矩阵
All_Time_Cost = []; % 存储所有函数的平均时间成本
All_Time_Cost_Detail = {}; % 存储详细的时间数据
All_Wilcoxon_P = {}; % 存储所有函数的Wilcoxon P值
All_Wilcoxon_H = {}; % 存储所有函数的Wilcoxon H值
All_Statistical_Results = {}; % 存储所有统计结果

%% CEC2017测试
for f = 1:30
    rng(rng_list(f));
    Func_name = strcat('F',num2str(f)); % 测试函数
    dim = 30;
    [lb,ub,dim,fobj] = Get_CEC2017_details(Func_name,dim); %维度，上下界
    
    %% 参数
    pop = 30; %种群数量
    maxIter = 500; %迭代次数
    k = 30; %运行次数

    result = {};
    name_list = {'MSCCO_wo1','MSCCO_wo2','MSCCO_wo3','MSCCO'};

    len = length(name_list);
    result.name = name_list;
    result.data = cell(1,len);
    for i = 1:len
        result.data{i} = zeros(k,maxIter);
    end

    Fitness_Avg = zeros(len,maxIter);
    Time_Cost = zeros(len, k); % 存储每个算法每次运行的时间

    %% 运行
    fprintf('正在运行函数 %s...\n', Func_name);

    algorithm_handles = {@MSCCO_wo1,@MSCCO_wo2,@MSCCO_wo3,@MSCCO};
    for i = 1:k
        for alg = 1:len
            tic;
            [~, ~, iter_curve] = algorithm_handles{alg}(pop, maxIter, lb, ub, dim, fobj);
            Time_Cost(alg, i) = toc;
            iter_curve = reshape(iter_curve, 1, []);
            if numel(iter_curve) ~= maxIter
                error('%s returned %d curve values; expected %d.', name_list{alg}, numel(iter_curve), maxIter);
            end
            result.data{alg}(i,:) = iter_curve;
        end
    end
    
    % 计算时间成本统计
    Time_Stats = struct();
    Time_Stats.mean = mean(Time_Cost, 2)'; % 平均时间
    Time_Stats.min = min(Time_Cost, [], 2)'; % 最小时间
    Time_Stats.max = max(Time_Cost, [], 2)'; % 最大时间
    Time_Stats.std = std(Time_Cost, 0, 2)'; % 标准差
    
    All_Time_Cost = [All_Time_Cost; Time_Stats.mean]; % 存储平均时间
    All_Time_Cost_Detail{f} = Time_Stats; % 存储详细时间统计
    
    %% Statistical Metrics
    num = len; % 改进算法统计基准
    
    % RGB Matrix
    IEEE_COLORS = [
        0.0000  0.4470  0.7410;   % blue
        0.8500  0.3250  0.0980;   % orange
        0.4660  0.6740  0.1880;   % green
        0.4940  0.1840  0.5560;   % purple
        0.9290  0.6940  0.1250;   % yellow
        0.3010  0.7450  0.9330;   % cyan
        0.6350  0.0780  0.1840;   % red
        0.2500  0.2500  0.2500;   % gray
        0.0000  0.6000  0.5000];  % teal
    RGBData = IEEE_COLORS(1:len, :);
    
    [Best_val,Worst_val,Mean_val,Median_val,Std_val,Wilcoxon_RankSum_Test,...
        Wilcoxon_SignedRank_Test,Friedamn_val] = Statis_Data(result,Func_name,num,RGBData);
    
    % 存储所有统计结果
    Stats = struct();
    Stats.Best = Best_val;
    Stats.Worst = Worst_val;
    Stats.Mean = Mean_val;
    Stats.Median = Median_val;
    Stats.Std = Std_val;
    Stats.Friedman = Friedamn_val;
    All_Statistical_Results{f} = Stats;
    
    % 存储Wilcoxon秩和检验结果
    temp_p = [];
    temp_h = [];
    idx = 1;
    for i = 1:len
        if i == num
            temp_p = [temp_p, NaN]; % 对比算法自己时为NaN
            temp_h = [temp_h, NaN];
        else
            temp_p = [temp_p, Wilcoxon_RankSum_Test(idx, 1)];
            temp_h = [temp_h, Wilcoxon_RankSum_Test(idx, 2)];
            idx = idx + 1;
        end
    end
    All_Wilcoxon_P{f} = temp_p;
    All_Wilcoxon_H{f} = temp_h;
    
    %% 统计结果
    [~,Friedamn_Idx] = sort(Friedamn_val);
    [~,Friedamn_Idx] = sort(Friedamn_Idx); % -->Integer
    res = [Best_val;Worst_val;Mean_val;Std_val;Friedamn_Idx];
    lin = 1:size(res,2);
    My_test_result{f} = [lin;res];

    colorList = RGBData; 
    markerList = {'o','s','^','d','v','p','h','x','*','+','>','<','.','_'};

    if ~exist('result', 'dir')
        mkdir('result');
    end
    
    % 绘制函数图
    figure('Visible', 'off');
    [x,y,fval] = Plot_CEC2017(Func_name,dim);
    surfc(x,y,fval,'LineStyle','none');
    colormap(slanCM(21))
    title(Func_name);
    func_filename = fullfile('result', [Func_name '_func.png']);
    saveas(gcf, func_filename);
    close(gcf);
    

    % 绘制收敛曲线
    MSBCA_data = result.data{end};
    final_fitness = MSBCA_data(:, end); 
    [~, best_run_idx] = min(final_fitness); 
    
    % 获取所有算法在最佳运行次数下的适应度曲线
    Fitness_Best = zeros(len, maxIter);
    for i = 1:len
        Fitness_Best(i,:) = result.data{i}(best_run_idx, :);
    end

    % Convergence curve plot
    figure('Visible', 'off', 'Color', 'w', 'Position', [100 100 560 420]);
    markerInterval = max(1, floor(maxIter / 15));
    hLines = gobjects(1, len);
    for i = 1:len
        tt = Fitness_Best(i,:);
        mk = markerList{mod(i-1, length(markerList)) + 1};
        hLines(i) = semilogy(tt, 'Color', colorList(i,:), 'LineWidth', 1.6, ...
            'Marker', mk, 'MarkerSize', 7, ...
            'MarkerIndices', 1:markerInterval:maxIter, ...
            'MarkerFaceColor', colorList(i,:), ...
            'MarkerEdgeColor', colorList(i,:)*0.7);
        hold on
    end
    hold off
    xlabel('Iteration', 'FontName', 'Times New Roman', 'FontSize', 12);
    ylabel('Fitness Value', 'FontName', 'Times New Roman', 'FontSize', 12);
    title(Func_name, 'FontName', 'Times New Roman', 'FontSize', 12, 'Interpreter', 'none');
    lg = legend(hLines, name_list, 'Interpreter', 'none', ...
        'FontName', 'Times New Roman', 'FontSize', 10, 'Location', 'best');
    legend boxon
    set(gca, 'FontName', 'Times New Roman', 'FontSize', 10, ...
        'TickLabelInterpreter', 'none', 'LineWidth', 1.0, 'Box', 'on', ...
        'XGrid', 'on', 'YGrid', 'on', 'GridLineStyle', ':', 'GridAlpha', 0.3);
    fitness_curve_filename = fullfile('result', [Func_name '_Best_fitness_curve.png']);
    saveas(gcf, fitness_curve_filename);
    close(gcf);
end

fprintf('\n所有函数运行完成！开始保存结果到Excel文件...\n');

% 统计结果
fprintf('保存基本统计结果...\n');
for f=1:30
    Function_name = strcat('F',num2str(f));
    writecell({Function_name ,'最优值','最差值','平均值','标准差','Friedamn排名'}...
        ,'CEC2017测试结果.xlsx','WriteMode','append');
    writematrix(My_test_result{f}','CEC2017测试结果.xlsx','WriteMode','append');
end

% 保存算法运行时间对比表（平均时间）
fprintf('保存时间成本对比表...\n');
time_header = ['函数', name_list, '单位'];
writecell(time_header, 'CEC2017_时间成本对比.xlsx', 'Sheet', 1, 'Range', 'A1');

for f = 1:30
    Function_name = strcat('F',num2str(f));
    time_values = All_Time_Cost(f, :);
    % 格式化时间值（保留4位小数）
    time_values_formatted = arrayfun(@(x) sprintf('%.4f', x), time_values, 'UniformOutput', false);
    row_data = [Function_name, time_values_formatted, '秒(s)'];
    row_idx = f + 1;
    range_str = sprintf('A%d', row_idx);
    writecell(row_data, 'CEC2017_时间成本对比.xlsx', 'Sheet', 1, 'Range', range_str);
end

% 保存详细时间统计表
fprintf('保存详细时间统计表...\n');
detail_header = [{'函数', '统计量'}, name_list];
writecell(detail_header, 'CEC2017_时间成本详细统计.xlsx', 'Sheet', 1, 'Range', 'A1');

row_idx = 2;
for f = 1:30
    Function_name = strcat('F',num2str(f));
    stats = All_Time_Cost_Detail{f};
    
    % 写入平均值
    mean_values = arrayfun(@(x) sprintf('%.4f', x), stats.mean, 'UniformOutput', false);
    writecell([Function_name, '平均值', mean_values], 'CEC2017_时间成本详细统计.xlsx', ...
        'Sheet', 1, 'Range', sprintf('A%d', row_idx));
    row_idx = row_idx + 1;
    
    % 写入最小值
    min_values = arrayfun(@(x) sprintf('%.4f', x), stats.min, 'UniformOutput', false);
    writecell([Function_name, '最小值', min_values], 'CEC2017_时间成本详细统计.xlsx', ...
        'Sheet', 1, 'Range', sprintf('A%d', row_idx));
    row_idx = row_idx + 1;
    
    % 写入最大值
    max_values = arrayfun(@(x) sprintf('%.4f', x), stats.max, 'UniformOutput', false);
    writecell([Function_name, '最大值', max_values], 'CEC2017_时间成本详细统计.xlsx', ...
        'Sheet', 1, 'Range', sprintf('A%d', row_idx));
    row_idx = row_idx + 1;
    
    % 写入标准差
    std_values = arrayfun(@(x) sprintf('%.4f', x), stats.std, 'UniformOutput', false);
    writecell([Function_name, '标准差', std_values], 'CEC2017_时间成本详细统计.xlsx', ...
        'Sheet', 1, 'Range', sprintf('A%d', row_idx));
    row_idx = row_idx + 1;
    
    % 添加空行
    row_idx = row_idx + 1;
end

% 保存Wilcoxon秩和检验P值表
fprintf('保存Wilcoxon秩和检验P值表...\n');
p_value_header = ['函数', name_list];
writecell(p_value_header, 'CEC2017_Wilcoxon秩和检验P值.xlsx', 'Sheet', 1, 'Range', 'A1');

for f = 1:30
    Function_name = strcat('F',num2str(f));
    p_values = All_Wilcoxon_P{f};
    
    % 格式化P值
    p_values_formatted = {};
    for i = 1:length(p_values)
        if isnan(p_values(i))
            p_values_formatted{i} = 'NaN';
        else
            % 根据P值大小选择不同的格式
            if p_values(i) < 0.001
                p_values_formatted{i} = sprintf('%.2E', p_values(i));
            else
                p_values_formatted{i} = sprintf('%.4f', p_values(i));
            end
        end
    end
    
    row_data = [Function_name, p_values_formatted];
    row_idx = f + 1;
    range_str = sprintf('A%d', row_idx);
    writecell(row_data, 'CEC2017_Wilcoxon秩和检验P值.xlsx', 'Sheet', 1, 'Range', range_str);
end

% 创建综合对比表
fprintf('保存Wilcoxon综合对比表...\n');
writecell(p_value_header, 'CEC2017_Wilcoxon综合对比表.xlsx', 'Sheet', 1, 'Range', 'A1');

for f = 1:30
    Function_name = strcat('F',num2str(f));
    p_values = All_Wilcoxon_P{f};
    h_values = All_Wilcoxon_H{f};
    
    % 格式化P值并添加显著性标记
    p_values_formatted = {};
    for i = 1:length(p_values)
        if isnan(p_values(i))
            p_values_formatted{i} = 'NaN';
        else
            if p_values(i) < 0.001
                if h_values(i) == 1
                    p_values_formatted{i} = sprintf('%.2E**', p_values(i));
                else
                    p_values_formatted{i} = sprintf('%.2E', p_values(i));
                end
            elseif p_values(i) < 0.01
                if h_values(i) == 1
                    p_values_formatted{i} = sprintf('%.3f**', p_values(i));
                else
                    p_values_formatted{i} = sprintf('%.3f', p_values(i));
                end
            elseif p_values(i) < 0.05
                if h_values(i) == 1
                    p_values_formatted{i} = sprintf('%.3f*', p_values(i));
                else
                    p_values_formatted{i} = sprintf('%.3f', p_values(i));
                end
            else
                p_values_formatted{i} = sprintf('%.3f', p_values(i));
            end
        end
    end
    
    row_data = [Function_name, p_values_formatted];
    row_idx = f + 1;
    range_str = sprintf('A%d', row_idx);
    writecell(row_data, 'CEC2017_Wilcoxon综合对比表.xlsx', 'Sheet', 1, 'Range', range_str);
end

% 添加说明
explanation = {
    '',
    '说明：',
    '** 表示在0.01显著性水平下有极显著差异 (p < 0.01)',
    '*  表示在0.05显著性水平下有显著差异 (0.01 ≤ p < 0.05)',
    'NaN 表示算法与自身对比',
    '',
    '注：所有P值均为与MSCCO算法（最后一列）的对比结果'
};

start_row = 33;
for i = 1:length(explanation)
    range_str = sprintf('A%d', start_row + i);
    writecell({explanation{i}}, 'CEC2017_Wilcoxon综合对比表.xlsx', 'Sheet', 1, 'Range', range_str);
end

% 创建算法性能排名汇总表
fprintf('保存算法性能排名汇总表...\n');
rank_header = ['函数', name_list];
writecell(rank_header, 'CEC2017_算法Friedman排名.xlsx', 'Sheet', 1, 'Range', 'A1');

for f = 1:30
    Function_name = strcat('F',num2str(f));
    stats = All_Statistical_Results{f};
    
    % 计算Friedman排名
    [~, friedman_idx] = sort(stats.Friedman);
    [~, friedman_rank] = sort(friedman_idx);
    
    row_data = [Function_name, num2cell(friedman_rank)];
    row_idx = f + 1;
    range_str = sprintf('A%d', row_idx);
    writecell(row_data, 'CEC2017_算法Friedman排名.xlsx', 'Sheet', 1, 'Range', range_str);
end

% 计算平均排名
avg_ranks = zeros(1, length(name_list));
for f = 1:30
    stats = All_Statistical_Results{f};
    [~, friedman_idx] = sort(stats.Friedman);
    [~, friedman_rank] = sort(friedman_idx);
    avg_ranks = avg_ranks + friedman_rank;
end
avg_ranks = avg_ranks / 30;

% 添加平均排名
row_idx = 32;
avg_rank_formatted = arrayfun(@(x) sprintf('%.2f', x), avg_ranks, 'UniformOutput', false);
writecell(['平均排名', avg_rank_formatted], 'CEC2017_算法Friedman排名.xlsx', ...
    'Sheet', 1, 'Range', sprintf('A%d', row_idx));
