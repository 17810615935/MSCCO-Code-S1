%% 单无人机路径代价
function [J, detail] = EvaluateSingleUAVCost(P, task_flag, model)

    n = size(P, 1);
    seg = diff(P, 1, 1);
    seg_len = sqrt(sum(seg.^2, 2));

    %% 路径长度代价
    L = sum(seg_len);
    task_pts = P(task_flag, :);
    D = sum(sqrt(sum(diff(task_pts, 1, 1).^2, 2)));
    JL = 1 - D / (L + eps);

    %% 高度代价
    z = P(~task_flag, 3);
    Hc = (model.Hmin + model.Hmax_fly) / 2;
    over_H = max(model.Hmin - z, 0) + max(z - model.Hmax_fly, 0);
    viol_H = sum(over_H > 0);
    if isempty(z)
        JH = 0;
    else
        JH = sum(abs(z - Hc) / (Hc + eps)) / numel(z);
    end

    %% 水平转弯角代价
    dx = seg(:, 1);
    dy = seg(:, 2);
    rho = sqrt(dx.^2 + dy.^2);
    if n >= 3
        dot_xy = dx(1:end-1) .* dx(2:end) + dy(1:end-1) .* dy(2:end);
        den = rho(1:end-1) .* rho(2:end);
        valid = den > 1e-9 & ~task_flag(2:n-1);
        theta = zeros(n-2, 1);
        theta(valid) = acos(min(max(dot_xy(valid) ./ den(valid), -1), 1));
        over_T = max(theta - model.theta_max, 0) / model.theta_max;
        viol_T = sum(over_T > 0);
        JT = sum(theta(valid) / (model.theta_max + eps)) / max(1, sum(valid));
    else
        over_T = 0;
        viol_T = 0;
        JT = 0;
    end

    %% 爬升角代价
    gamma = atan(abs(seg(:, 3)) ./ (rho + eps));
    over_C = max(gamma - model.gamma_max, 0) / model.gamma_max;
    viol_C = sum(over_C > 0);
    JC = sum(gamma / (model.gamma_max + eps)) / max(1, numel(gamma));

    JS = JT + JC;

    %% 威胁规避代价
    A = P(1:end-1, :);
    B = P(2:end, :);
    zlow = min(A(:, 3), B(:, 3));
    JD = 0;
    viol_weather = 0;
    viol_em = 0;
    viol_nofly = 0;
    over_D = 0;

    for k = 1:size(model.weather_zones, 1)
        c = model.weather_zones(k, 1:2);
        R = model.weather_zones(k, 3);
        d = SegDist(c, A(:, 1:2), B(:, 1:2));
        [cost, v, depth] = ThreatPenalty(d, R, model);
        JD = JD + sum(cost);
        viol_weather = viol_weather + sum(v);
        over_D = over_D + sum(depth);
    end

    for k = 1:size(model.em_zones, 1)
        c = model.em_zones(k, 1:2);
        R = model.em_zones(k, 3);
        H = model.em_zones(k, 4);
        active = zlow <= H;
        if ~any(active)
            continue;
        end
        d = SegDist(c, A(active, 1:2), B(active, 1:2));
        [cost, v, depth] = ThreatPenalty(d, R, model);
        JD = JD + sum(cost);
        viol_em = viol_em + sum(v);
        za = zlow(active);
        over_D = over_D + sum(min(depth, (H - za(v)) / H + 1));
    end

    for k = 1:size(model.no_fly_zones, 1)
        c = model.no_fly_zones(k, 1:3);
        R = model.no_fly_zones(k, 4);
        d = SegDist(c, A, B);
        [cost, v, depth] = ThreatPenalty(d, R, model);
        JD = JD + sum(cost);
        viol_nofly = viol_nofly + sum(v);
        over_D = over_D + sum(depth);
    end

    [hit, depth_B] = SegBoxHit(A, B, model.box_min, model.box_max);
    viol_B = sum(hit);
    viol_D = viol_weather + viol_em + viol_nofly;

    %% 单无人机综合代价
    J = model.wL * JL + model.wH * JH + model.wS * JS + model.wD * JD;

    detail.length = L;
    detail.direct = D;
    detail.JL = JL;
    detail.JH = JH;
    detail.JT = JT;
    detail.JC = JC;
    detail.JS = JS;
    detail.JD = JD;
    detail.J = J;
    detail.viol_H = viol_H;
    detail.viol_T = viol_T;
    detail.viol_C = viol_C;
    detail.viol_D = viol_D;
    detail.viol_weather = viol_weather;
    detail.viol_em = viol_em;
    detail.viol_nofly = viol_nofly;
    detail.viol_B = viol_B;
    detail.violations = viol_H + viol_T + viol_C + viol_D + viol_B;
    detail.viol_kinematic = viol_H + viol_T + viol_C;
    detail.viol_geometry = viol_B;
    detail.viol_safety = viol_D;
    detail.viol_hard = detail.violations;
    detail.penalty = detail.violations + sum(over_H) / Hc + sum(over_T) + ...
        sum(over_C) + over_D + depth_B;
end

function [cost, viol, depth] = ThreatPenalty(d, R, model)
    inner = model.D + R;
    outer = inner + model.S;
    cost = zeros(size(d));
    viol = d <= inner;
    band = d > inner & d < outer;
    cost(band) = 1 - (d(band) - inner) / model.S;
    cost(viol) = 1;
    depth = (inner - d(viol)) / inner;
end

function d = SegDist(C, A, B)
    AB = B - A;
    t = sum((C - A) .* AB, 2) ./ max(sum(AB.^2, 2), eps);
    t = min(max(t, 0), 1);
    d = sqrt(sum((C - (A + t .* AB)).^2, 2));
end

function [seg_hit, depth] = SegBoxHit(A, B, bmin, bmax)
    m = size(A, 1);
    nb = size(bmin, 1);
    dir = B - A;
    tmin = zeros(m, nb);
    tmax = ones(m, nb);
    ok = true(m, nb);

    for ax = 1:3
        a = A(:, ax);
        d = dir(:, ax);
        par = abs(d) < 1e-12;
        d(par) = 1;
        t1 = (bmin(:, ax)' - a) ./ d;
        t2 = (bmax(:, ax)' - a) ./ d;
        lo = min(t1, t2);
        hi = max(t1, t2);
        lo(par, :) = -Inf;
        hi(par, :) = Inf;
        outside = par & ((a < bmin(:, ax)') | (a > bmax(:, ax)'));
        ok = ok & ~outside;
        tmin = max(tmin, lo);
        tmax = min(tmax, hi);
    end

    hit = ok & (tmin <= tmax);
    seg_hit = any(hit, 2);
    zlow = min(A(:, 3), B(:, 3));
    gap = max(bmax(:, 3)' - zlow, 0) ./ bmax(:, 3)';
    depth = sum(gap(hit));
end
