function [Best_val, Worst_val, Mean_val, Median_val, Std_val, Wilcoxon_RankSum_Test, Wilcoxon_SignedRank_Test, Friedamn_val] = Statis_Data(result, Func_name, num, RGBData)

len = length(result.name);
[k, ~] = size(result.data{1});
data = zeros(len, k);

for i = 1:len
    mat = result.data{i};
    data(i, :) = mat(:, end)';
end

Best_val = zeros(1, len);
Worst_val = zeros(1, len);
Mean_val = zeros(1, len);
Median_val = zeros(1, len);
Std_val = zeros(1, len);
Wilcoxon_RankSum_Test = [];
Wilcoxon_SignedRank_Test = [];

[~, ~, stats] = friedman(data', 1, 'off');
Friedamn_val = stats.meanranks;
end
