%% 四种场景全部算法对比实验
clear, clc, close all
root_dir = fileparts(mfilename('fullpath'));
cd(root_dir);
addpath(root_dir);
warning('off');

%% 实验配置
scenario_list = 1:4;
algorithm_list = {'GWO','PSO','SO','DBA','NDO','SBOA','BKA','OOA','JADE','CCO','MSCCO'};
runs = 10;
pop = 30;
maxIter = 500;
result_dir = 'result';
excel_file = fullfile(result_dir, '四场景算法对比结果.xlsx');

if ~exist(result_dir, 'dir')
    mkdir(result_dir);
end
if exist(excel_file, 'file')
    delete(excel_file);
end

num_alg = numel(algorithm_list);
num_sc = numel(scenario_list);
summary_mean = zeros(num_sc, num_alg);
summary_rank = zeros(num_sc, num_alg);
summary_feas = zeros(num_sc, num_alg);
summary_geometry = zeros(num_sc, num_alg);
summary_safety = zeros(num_sc, num_alg);
summary_kinematic = zeros(num_sc, num_alg);
summary_hard = zeros(num_sc, num_alg);

for si = 1:num_sc
    sid = scenario_list(si);
    fprintf('\n==================== 场景%d ====================\n', sid);
    rng(100 + sid);
    [model, problem, scene, assignment] = SetupScenario(sid);
    fobj = @(x) CalculateTotalCost(x, problem, model);
    fprintf('  决策维度: %d\n', problem.dim);

    fit = zeros(runs, num_alg);
    feas = false(runs, num_alg);
    plen = zeros(runs, num_alg);
    tcost = zeros(runs, num_alg);
    curves = zeros(num_alg, maxIter, runs);
    pos = cell(runs, num_alg);
    viol_geometry = zeros(runs, num_alg);
    viol_safety = zeros(runs, num_alg);
    viol_kinematic = zeros(runs, num_alg);
    viol_building = zeros(runs, num_alg);
    viol_weather = zeros(runs, num_alg);
    viol_em = zeros(runs, num_alg);
    viol_nofly = zeros(runs, num_alg);
    viol_space = zeros(runs, num_alg);
    viol_hard = zeros(runs, num_alg);
    comm_off = zeros(runs, num_alg);

    %% 运行
    for r = 1:runs
        for a = 1:num_alg
            rng(1000 * sid + r);
            tic;
            [bf, bp, cv] = RunAlgorithm(algorithm_list{a}, pop, maxIter, ...
                problem.lb, problem.ub, problem.dim, fobj);
            tcost(r, a) = toc;
            [~, info] = CalculateTotalCost(bp, problem, model);
            fit(r, a) = bf;
            feas(r, a) = info.feasible;
            plen(r, a) = sum(cellfun(@(d) d.length, info.uav_detail));
            viol_geometry(r, a) = info.viol_geometry;
            viol_safety(r, a) = info.viol_safety;
            viol_kinematic(r, a) = info.viol_kinematic;
            viol_building(r, a) = info.viol_building;
            viol_weather(r, a) = info.viol_weather;
            viol_em(r, a) = info.viol_em;
            viol_nofly(r, a) = info.viol_nofly;
            viol_space(r, a) = info.viol_space;
            viol_hard(r, a) = info.viol_hard;
            comm_off(r, a) = info.N_off;
            curves(a, :, r) = cv;
            pos{r, a} = bp;
        end
        fprintf('  第%2d次  ', r);
        line = [algorithm_list; num2cell(fit(r, :))];
        fprintf('%s=%.4f  ', line{:});
        fprintf('\n');
    end

    %% 统计
    best_v = min(fit, [], 1);
    worst_v = max(fit, [], 1);
    mean_v = mean(fit, 1);
    std_v = std(fit, 0, 1);
    median_v = median(fit, 1);
    feas_rate = mean(feas, 1);
    len_v = mean(plen, 1);
    time_v = mean(tcost, 1);
    geometry_v = mean(viol_geometry, 1);
    safety_v = mean(viol_safety, 1);
    kinematic_v = mean(viol_kinematic, 1);
    hard_v = mean(viol_hard, 1);
    max_geometry_v = max(viol_geometry, [], 1);
    max_safety_v = max(viol_safety, [], 1);
    max_kinematic_v = max(viol_kinematic, [], 1);
    max_hard_v = max(viol_hard, [], 1);
    feasible_runs = sum(feas, 1);

    run_rank = zeros(runs, num_alg);
    for r = 1:runs
        run_rank(r, :) = tiedrank(fit(r, :));
    end
    friedman_v = mean(run_rank, 1);
    [~, order] = sort(friedman_v);
    final_rank = zeros(1, num_alg);
    final_rank(order) = 1:num_alg;

    p_val = nan(1, num_alg);
    for a = 1:num_alg-1
        p_val(a) = ranksum(fit(:, a), fit(:, end));
    end

    summary_mean(si, :) = mean_v;
    summary_rank(si, :) = friedman_v;
    summary_feas(si, :) = feas_rate;
    summary_geometry(si, :) = geometry_v;
    summary_safety(si, :) = safety_v;
    summary_kinematic(si, :) = kinematic_v;
    summary_hard(si, :) = hard_v;

    fprintf('\n  %-6s %12s %12s %12s %10s %8s %8s %10s\n', '算法', '最优值', '平均值', '标准差', '可行率', 'Friedman', '排名', 'P值');
    for a = 1:num_alg
        fprintf('  %-6s %12.4f %12.4f %12.4f %10.2f %8.2f %8d %10.2e\n', algorithm_list{a}, ...
            best_v(a), mean_v(a), std_v(a), feas_rate(a), friedman_v(a), final_rank(a), p_val(a));
    end

    %% 保存Excel
    header = [{'指标'}, algorithm_list];
    rows = {'最优值', best_v; '最差值', worst_v; '平均值', mean_v; '标准差', std_v; ...
        '中位数', median_v; '可行率', feas_rate; '平均航程(m)', len_v; ...
        '平均耗时(s)', time_v; 'Friedman平均秩', friedman_v; '排名', final_rank; ...
        'Wilcoxon P值', p_val; ...
        '平均几何硬违规数', geometry_v; '最大几何硬违规数', max_geometry_v; ...
        '平均安全硬违规数', safety_v; '最大安全硬违规数', max_safety_v; ...
        '平均运动学硬违规数', kinematic_v; '最大运动学硬违规数', max_kinematic_v; ...
        '平均建筑物相交次数', mean(viol_building, 1); ...
        '平均天气区侵入次数', mean(viol_weather, 1); ...
        '平均电磁区侵入次数', mean(viol_em, 1); ...
        '平均禁飞区侵入次数', mean(viol_nofly, 1); ...
        '平均无人机间距碰撞次数', mean(viol_space, 1); ...
        '平均总硬违规数', hard_v; '最大总硬违规数', max_hard_v; ...
        '可行运行次数', feasible_runs};
    sheet = sprintf('场景%d', sid);
    writecell(header, excel_file, 'Sheet', sheet, 'Range', 'A1');
    for k = 1:size(rows, 1)
        writecell([rows(k, 1), num2cell(rows{k, 2})], excel_file, 'Sheet', sheet, ...
            'Range', sprintf('A%d', k + 1));
    end
    writecell([{'运行次数'}, algorithm_list], excel_file, 'Sheet', sheet, ...
        'Range', sprintf('A%d', size(rows, 1) + 3));
    writecell([num2cell((1:runs)'), num2cell(fit)], excel_file, 'Sheet', sheet, ...
        'Range', sprintf('A%d', size(rows, 1) + 4));

    %% 保存每次运行的硬违规分类明细
    detail_sheet = sprintf('场景%d_硬违规', sid);
    detail_header = {'运行次数', '算法', '几何硬违规数', '安全硬违规数', ...
        '运动学硬违规数', '建筑物相交', '天气区侵入', '电磁区侵入', ...
        '禁飞区侵入', '无人机间距碰撞', '总硬违规数', '可行', '通信中断次数'};
    detail_rows = cell(runs * num_alg, numel(detail_header));
    row_id = 0;
    for r0 = 1:runs
        for a0 = 1:num_alg
            row_id = row_id + 1;
            detail_rows(row_id, :) = {r0, algorithm_list{a0}, ...
                viol_geometry(r0, a0), viol_safety(r0, a0), viol_kinematic(r0, a0), ...
                viol_building(r0, a0), viol_weather(r0, a0), viol_em(r0, a0), ...
                viol_nofly(r0, a0), viol_space(r0, a0), viol_hard(r0, a0), ...
                feas(r0, a0), comm_off(r0, a0)};
        end
    end
    writecell(detail_header, excel_file, 'Sheet', detail_sheet, 'Range', 'A1');
    writecell(detail_rows, excel_file, 'Sheet', detail_sheet, 'Range', 'A2');

    save(fullfile(result_dir, sprintf('scenario%d.mat', sid)), 'fit', 'feas', 'plen', ...
        'tcost', 'curves', 'pos', 'algorithm_list', 'assignment', 'model', 'problem', 'scene', ...
        'viol_geometry', 'viol_safety', 'viol_kinematic', 'viol_building', ...
        'viol_weather', 'viol_em', 'viol_nofly', 'viol_space', 'viol_hard', 'comm_off');

    %% 绘图
    [~, best_run] = min(fit(:, end));
    fig = PlotConvergence(curves(:, :, best_run), algorithm_list, sprintf('Scenario %d', sid));
    exportgraphics(fig, fullfile(result_dir, sprintf('场景%d_收敛曲线.png', sid)), 'Resolution', 300);

    fig = PlotConvergence(mean(curves, 3), algorithm_list, sprintf('Scenario %d (Mean)', sid));
    exportgraphics(fig, fullfile(result_dir, sprintf('场景%d_平均收敛曲线.png', sid)), 'Resolution', 300);

    fig = figure('Color', 'w', 'Position', [150, 150, 760, 440]);
    boxplot(fit, 'Labels', algorithm_list);
    set(gca, 'YScale', 'log', 'FontName', 'Times New Roman', 'FontSize', 10);
    ylabel('Fitness Value', 'FontName', 'Times New Roman', 'FontSize', 12);
    title(sprintf('Scenario %d', sid), 'FontName', 'Times New Roman', 'FontWeight', 'normal');
    grid on;
    exportgraphics(fig, fullfile(result_dir, sprintf('场景%d_箱线图.png', sid)), 'Resolution', 300);

    ExportAlgorithmPaths(model, problem, scene, assignment, sid, algorithm_list, fit, pos, result_dir);
    close all;
end

%% 汇总
overall_rank = mean(summary_rank, 1);
[~, order] = sort(overall_rank);
overall_pos = zeros(1, num_alg);
overall_pos(order) = 1:num_alg;

writecell([{'场景'}, algorithm_list], excel_file, 'Sheet', '汇总', 'Range', 'A1');
for si = 1:num_sc
    writecell([{sprintf('场景%d平均值', scenario_list(si))}, num2cell(summary_mean(si, :))], ...
        excel_file, 'Sheet', '汇总', 'Range', sprintf('A%d', si + 1));
    writecell([{sprintf('场景%d可行率', scenario_list(si))}, num2cell(summary_feas(si, :))], ...
        excel_file, 'Sheet', '汇总', 'Range', sprintf('A%d', num_sc + si + 1));
    writecell([{sprintf('场景%d平均几何硬违规', scenario_list(si))}, num2cell(summary_geometry(si, :))], ...
        excel_file, 'Sheet', '汇总', 'Range', sprintf('A%d', 3*num_sc + si + 1));
    writecell([{sprintf('场景%d平均安全硬违规', scenario_list(si))}, num2cell(summary_safety(si, :))], ...
        excel_file, 'Sheet', '汇总', 'Range', sprintf('A%d', 4*num_sc + si + 1));
    writecell([{sprintf('场景%d平均运动学硬违规', scenario_list(si))}, num2cell(summary_kinematic(si, :))], ...
        excel_file, 'Sheet', '汇总', 'Range', sprintf('A%d', 5*num_sc + si + 1));
    writecell([{sprintf('场景%d平均总硬违规', scenario_list(si))}, num2cell(summary_hard(si, :))], ...
        excel_file, 'Sheet', '汇总', 'Range', sprintf('A%d', 6*num_sc + si + 1));
    writecell([{sprintf('场景%dFriedman秩', scenario_list(si))}, num2cell(summary_rank(si, :))], ...
        excel_file, 'Sheet', '汇总', 'Range', sprintf('A%d', 7*num_sc + si + 1));
end
writecell([{'平均Friedman秩'}, num2cell(overall_rank)], excel_file, 'Sheet', '汇总', ...
    'Range', sprintf('A%d', 8*num_sc + 2));
writecell([{'综合排名'}, num2cell(overall_pos)], excel_file, 'Sheet', '汇总', ...
    'Range', sprintf('A%d', 8*num_sc + 3));

fprintf('\n==================== 综合排名 ====================\n');
for k = 1:num_alg
    a = order(k);
    fprintf('  %2d  %-6s  平均Friedman秩 %.2f\n', k, algorithm_list{a}, overall_rank(a));
end
