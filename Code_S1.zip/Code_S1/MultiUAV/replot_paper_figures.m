%% 按论文图17–图21重绘场景图与 MSCCO/PSO 路径图
clearvars
close all
root_dir = fileparts(mfilename('fullpath'));
addpath(root_dir);
result_dir = fullfile(root_dir, 'result');
paper_fig = 'C:\Users\25282\Desktop\新建文件夹\figures';
assert(exist(paper_fig, 'dir') == 7, '论文 figures 目录不存在。');

old_visibility = get(groot, 'DefaultFigureVisible');
set(groot, 'DefaultFigureVisible', 'off');
keep_algs = {'MSCCO', 'PSO'};
try
    for sid = 1:4
        data = load(fullfile(result_dir, sprintf('scenario%d.mat', sid)));
        assert(isfield(data, 'model') && isfield(data, 'scene') && isfield(data, 'problem'), ...
            'scenario%d.mat 缺少 model/scene/problem。', sid);
        model = data.model;
        problem = data.problem;
        scene = data.scene;
        assignment = data.assignment;

        fig_sc = PlotScenarioMap(model, scene, sid);
        exportgraphics(fig_sc, fullfile(paper_fig, sprintf('fig_scenario_%d.png', sid)), 'Resolution', 300);
        close(fig_sc);

        for k = 1:numel(keep_algs)
            hit = find(strcmp(data.algorithm_list, keep_algs{k}), 1);
            assert(~isempty(hit), '场景%d缺少算法%s。', sid, keep_algs{k});
            [~, best_run] = min(data.fit(:, hit));
            bp = data.pos{best_run, hit};
            [~, info] = CalculateTotalCost(bp, problem, model);
            [fig_path, ~] = PlotResults(model, scene.distribution_center, scene.warehouses, ...
                scene.delivery_points, info, assignment, sid, keep_algs{k}, false);
            out_name = sprintf('fig_path_s%d_%s.png', sid, lower(keep_algs{k}));
            exportgraphics(fig_path, fullfile(paper_fig, out_name), 'Resolution', 300);
            close(fig_path);
            fprintf('Wrote %s\n', out_name);
        end
    end
catch ME
    set(groot, 'DefaultFigureVisible', old_visibility);
    rethrow(ME);
end
set(groot, 'DefaultFigureVisible', old_visibility);
fprintf('Paper figures written to %s\n', paper_fig);
