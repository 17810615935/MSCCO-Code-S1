%% 绘制3D威胁区域
function DrawEMThreatZones3D(no_fly_zones, em_zones, weather_zones, max_z)

    % 空中禁飞区
    for i = 1:size(no_fly_zones, 1)
        cx = no_fly_zones(i, 1);
        cy = no_fly_zones(i, 2);
        cz = no_fly_zones(i, 3);
        radius = no_fly_zones(i, 4);

        [X, Y, Z] = sphere(36);

        if i == 1
            visibility = 'on';
            name = 'No-Fly Zone';
        else
            visibility = 'off';
            name = '';
        end

        surf(cx + radius*X, cy + radius*Y, cz + radius*Z, ...
            'FaceColor', [0.84, 0.25, 0.21], ...
            'EdgeColor', 'none', ...
            'FaceAlpha', 0.48, ...
            'HandleVisibility', visibility, ...
            'DisplayName', name);
    end

    % 电磁威胁区
    for i = 1:size(em_zones, 1)
        cx = em_zones(i, 1);
        cy = em_zones(i, 2);
        radius = em_zones(i, 3);
        z_max = em_zones(i, 4);

        theta = linspace(0, 2*pi, 42);
        z = linspace(0, z_max, 14);
        [Theta, Z] = meshgrid(theta, z);
        X = cx + radius*cos(Theta);
        Y = cy + radius*sin(Theta);

        if i == 1
            visibility = 'on';
            name = 'EM Threat Zone';
        else
            visibility = 'off';
            name = '';
        end

        surf(X, Y, Z, ...
            'FaceColor', [0.52, 0.27, 0.20], ...
            'EdgeColor', 'none', ...
            'FaceAlpha', 0.50, ...
            'HandleVisibility', visibility, ...
            'DisplayName', name);
    end

    % 恶劣天气区
    for i = 1:size(weather_zones, 1)
        cx = weather_zones(i, 1);
        cy = weather_zones(i, 2);
        radius = weather_zones(i, 3);

        theta = linspace(0, 2*pi, 42);
        z = linspace(0, max_z, 16);
        [Theta, Z] = meshgrid(theta, z);
        X = cx + radius*cos(Theta);
        Y = cy + radius*sin(Theta);

        if i == 1
            visibility = 'on';
            name = 'Weather Zone';
        else
            visibility = 'off';
            name = '';
        end

        surf(X, Y, Z, ...
            'FaceColor', [0.10, 0.24, 0.72], ...
            'EdgeColor', 'none', ...
            'FaceAlpha', 0.34, ...
            'HandleVisibility', visibility, ...
            'DisplayName', name);
    end
end
