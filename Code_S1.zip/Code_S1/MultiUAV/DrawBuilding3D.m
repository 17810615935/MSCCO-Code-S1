%% 绘制3D建筑物
function DrawBuilding3D(building_info, max_h, show_legend)
    x = building_info(1);
    y = building_info(2);
    w = building_info(3);
    d = building_info(4);
    h = building_info(5);

    if nargin < 3
        show_legend = false;
    end

    % 顶点
    vertices = [
        x,   y,   0;
        x+w, y,   0;
        x+w, y+d, 0;
        x,   y+d, 0;
        x,   y,   h;
        x+w, y,   h;
        x+w, y+d, h;
        x,   y+d, h;
    ];

    % 面
    faces = [
        1 2 6 5;
        2 3 7 6;
        3 4 8 7;
        4 1 5 8;
        5 6 7 8;
        1 2 3 4;
    ];

    c = h / max_h;
    color = [0.34 + 0.08*c, 0.72 + 0.08*c, 0.82 + 0.06*c];

    if show_legend
        visibility = 'on';
        name = 'Building';
    else
        visibility = 'off';
        name = '';
    end

    patch('Vertices', vertices, 'Faces', faces, ...
        'FaceColor', color, ...
        'EdgeColor', [0.18, 0.48, 0.54], ...
        'FaceAlpha', 0.84, ...
        'LineWidth', 0.45, ...
        'HandleVisibility', visibility, ...
        'DisplayName', name);
end
