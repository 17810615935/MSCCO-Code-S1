clear,clc,close all
rootDir = fileparts(mfilename('fullpath'));
cd(rootDir);
addpath(rootDir);
rng_list = ones(1,30);

%% 仅输出 Friedman 排名表
excel_file = 'CEC2017_算法Friedman排名.xlsx';
if exist(excel_file, 'file')
    delete(excel_file);
    fprintf('已删除文件: %s\n', excel_file);
end

%% CEC2017测试
name_list = {'MSCCO_wo1','MSCCO_wo2','MSCCO_wo3','MSCCO'};
algorithm_handles = {@MSCCO_wo1,@MSCCO_wo2,@MSCCO_wo3,@MSCCO};
len = length(name_list);
All_Friedman_Ranks = zeros(30, len);

for f = 1:30
    rng(rng_list(f));
    Func_name = strcat('F',num2str(f));
    dim = 100;
    [lb,ub,dim,fobj] = Get_CEC2017_details(Func_name,dim);

    %% 参数
    pop = 30;
    maxIter = 500;
    k = 30;

    result_data = cell(1,len);
    for i = 1:len
        result_data{i} = zeros(k,maxIter);
    end

    fprintf('正在运行函数 %s (Dim=%d)...\n', Func_name, dim);

    for i = 1:k
        for alg = 1:len
            [~, ~, iter_curve] = algorithm_handles{alg}(pop, maxIter, lb, ub, dim, fobj);
            iter_curve = reshape(iter_curve, 1, []);
            if numel(iter_curve) ~= maxIter
                error('%s returned %d curve values; expected %d.', name_list{alg}, numel(iter_curve), maxIter);
            end
            result_data{alg}(i,:) = iter_curve;
        end
    end

    data = zeros(len, k);
    for i = 1:len
        data(i, :) = result_data{i}(:, end)';
    end
    [~, ~, stats] = friedman(data', 1, 'off');
    [~, friedman_idx] = sort(stats.meanranks);
    [~, friedman_rank] = sort(friedman_idx);
    All_Friedman_Ranks(f,:) = friedman_rank;
end

fprintf('\n所有函数运行完成！保存Friedman排名表...\n');
rank_header = ['函数', name_list];
writecell(rank_header, excel_file, 'Sheet', 1, 'Range', 'A1');

for f = 1:30
    Function_name = strcat('F',num2str(f));
    row_data = [Function_name, num2cell(All_Friedman_Ranks(f,:))];
    writecell(row_data, excel_file, 'Sheet', 1, 'Range', sprintf('A%d', f + 1));
end

avg_ranks = mean(All_Friedman_Ranks, 1);
avg_rank_formatted = arrayfun(@(x) sprintf('%.2f', x), avg_ranks, 'UniformOutput', false);
writecell(['平均排名', avg_rank_formatted], excel_file, 'Sheet', 1, 'Range', 'A32');
fprintf('完成。结果已保存至 %s\n', excel_file);
