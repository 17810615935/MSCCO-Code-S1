%% 仅绘制场景三维地图（不含航迹），图例置于三维坐标轴右侧空白处
function fig = PlotScenarioMap(model, scene, scenario_id)

    buildings = model.buildings;
    max_h = max(buildings(:, 5));

    fig = figure('Name', sprintf('Scenario %d', scenario_id), ...
        'Position', [40, 40, 1180, 780], 'Color', 'w');
    ax = axes('Parent', fig, 'Position', [0.078, 0.088, 0.62, 0.84]);
    hold on;
    for i = 1:size(buildings, 1)
        DrawBuilding3D(buildings(i, :), max_h, i == 1);
    end
    DrawEMThreatZones3D(model.no_fly_zones, model.em_zones, ...
        model.weather_zones, model.MAPSIZE_Z);
    DrawTaskPoints3D(scene.distribution_center, scene.warehouses, scene.delivery_points);

    xlabel('X (m)', 'FontSize', 11);
    ylabel('Y (m)', 'FontSize', 11);
    zlabel('Height (m)', 'FontSize', 11);
    xlim([0, model.MAPSIZE_X]);
    ylim([0, model.MAPSIZE_Y]);
    zlim([0, model.MAPSIZE_Z]);
    xticks(0:100:500);
    yticks(0:100:500);
    zticks(0:20:100);
    view(-37.5, 24);
    pbaspect([1, 1, 0.56]);
    camzoom(1.42);
    grid on;
    box on;
    set(ax, 'Color', [0.93, 0.95, 0.97], 'FontSize', 9, ...
        'GridAlpha', 0.16, 'GridColor', [0.45, 0.45, 0.45], ...
        'LineWidth', 0.7, 'Projection', 'perspective', 'SortMethod', 'childorder');
    title(sprintf('Scenario %d', scenario_id), 'FontSize', 13, 'FontWeight', 'normal');
    lgd = legend('Location', 'northeast', 'FontSize', 9, 'Box', 'on');
    camlight('headlight');
    lighting gouraud;
    hold off;
    drawnow;

    axp = ax.Position;
    lgd.Units = 'normalized';
    lp = lgd.Position;
    gap_left = axp(1) + axp(3) + 0.012;
    if gap_left + lp(3) > 0.985
        gap_left = 0.985 - lp(3);
    end
    bot = axp(2) + axp(4) - lp(4) - 0.012;
    if bot < axp(2)
        bot = axp(2);
    end
    lgd.Position = [gap_left, bot, lp(3), lp(4)];
end
