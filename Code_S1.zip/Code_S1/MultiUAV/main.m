%% 城市物流配送无人机群协同路径规划（ALNS任务分配 + 路径优化）
clear, clc, close all
root_dir = fileparts(mfilename('fullpath'));
cd(root_dir);
addpath(root_dir);
warning('off');

%% 实验配置
scenario_id = 1;
algorithm_list = {'GWO','PSO','SO','DBA','NDO','SBOA','BKA','OOA','JADE','CCO','MSCCO'};
pop = 30;
maxIter = 500;
rng(1);

%% 场景与任务分配
fprintf('\n[任务分配] ALNS运行中...\n');
[model, problem, scene, assignment] = SetupScenario(scenario_id);
fobj = @(x) CalculateTotalCost(x, problem, model);
fprintf('\n[路径规划] 决策维度: %d\n', problem.dim);

%% 算法对比
num_alg = numel(algorithm_list);
results = struct('name', algorithm_list, 'best_fit', [], 'best_pos', [], ...
    'curve', [], 'time', [], 'info', []);

for a = 1:num_alg
    rng(1);
    tic;
    [best_fit, best_pos, curve] = RunAlgorithm(algorithm_list{a}, pop, maxIter, ...
        problem.lb, problem.ub, problem.dim, fobj);
    results(a).time = toc;
    [~, info] = CalculateTotalCost(best_pos, problem, model);
    results(a).best_fit = best_fit;
    results(a).best_pos = best_pos;
    results(a).curve = curve;
    results(a).info = info;

    total_len = sum(cellfun(@(d) d.length, info.uav_detail));
    fprintf('  %-6s  代价: %10.4f  总航程: %8.1f m  违约: %3d  可行: %d  耗时: %.2f s\n', ...
        algorithm_list{a}, best_fit, total_len, info.violations, info.feasible, results(a).time);
end

%% 输出最终算法结果
final = results(end);
info = final.info;
fprintf('\n========================================\n');
fprintf('  场景%d  %s\n', scenario_id, final.name);
fprintf('========================================\n');
for uav = 1:model.num_uavs
    d = info.uav_detail{uav};
    fprintf('  UAV%d: L=%.1f m  JL=%.4f  JH=%.4f  JS=%.4f  JD=%.4f  违约=%d\n', ...
        uav, d.length, d.JL, d.JH, d.JS, d.JD, d.violations);
end
fprintf('  J_UAV=%.4f  J_space=%.4f  J_comm=%.4f  N_off=%d/%d\n', ...
    info.J_UAV, info.J_space, info.J_comm, info.N_off, model.Nc_max);
fprintf('  J_total=%.4f  J_eval=%.4f  可行=%d\n', info.J_total, info.J_eval, info.feasible);

%% 可视化
% 单次调试结果使用独立输出目录，避免覆盖多次实验的最优路径图。
path_dir = fullfile(root_dir, 'result', '单次运行');
ExportAlgorithmPaths(model, problem, scene, assignment, scenario_id, ...
    algorithm_list, [results.best_fit], {results.best_pos}, path_dir);
PlotConvergence(reshape([results.curve], maxIter, [])', algorithm_list, sprintf('Scenario %d', scenario_id));
