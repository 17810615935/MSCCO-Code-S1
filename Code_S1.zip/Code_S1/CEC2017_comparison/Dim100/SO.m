% 薛定谔优化算法 SO
function [Best_fitness, Best_pos, Iter_curve] = SO(pop, maxIter, lb, ub, dim, fobj)

%% 边界处理
if size(lb,1) == 1
    lb = lb .* ones(1,dim);
    ub = ub .* ones(1,dim);
end

%% 算法参数
L = 0.5;            % 特征长度
h = 6.625e-34;      % 普朗克常数
k = 1;              % 位移系数

%% 初始化种群位置
Positions = zeros(pop, dim);
for i = 1:pop
    for j = 1:dim
        Positions(i,j) = (ub(j) - lb(j)) * rand() + lb(j);
    end
end

%% 初始化波函数与适应度
Psai = zeros(pop, dim);
Cost = inf(1, pop);
for i = 1:pop
    for j = 1:dim
        Positions(i,j) = min(max(Positions(i,j), lb(j)), ub(j));
        Psai(i,j) = sqrt(2/L) * sin(Positions(i,j)) * exp(2);
    end
    Cost(i) = fobj(Positions(i,:));
end

%% 初始最优/最差波函数
[~, indexSort] = sort(Cost);
Best_Cost  = Cost(indexSort(1));
Worst_Cost = Cost(indexSort(pop));
Best_X     = Positions(indexSort(1), :);
Best_Psai  = Psai(indexSort(1), :);
Worst_Psai = Psai(indexSort(pop), :);

Iter_curve = zeros(1, maxIter);

for l = 1:maxIter
    % 非线性收敛因子
    b = 1 - (l ^ (1.0/5)) / (maxIter ^ (1.0/5));

    % 按适应度排序, 取当前最优/最差波函数
    [~, indexSort] = sort(Cost);
    Best_Psai  = Psai(indexSort(1), :);
    Worst_Psai = Psai(indexSort(pop), :);

    p = ((pop:-1:1) / pop) .^ 2;

    for i = 1:pop
        h2 = p(i);
        vc = -b + 2 * b * rand(1, dim);     
        Z  = Levy(dim);                   

        if rand < 0.03
            Xnew = rand(1,dim) .* (ub - lb) + lb;
        else
            % 随机选取两个不同于当前个体的个体
            ids  = setdiff(1:pop, i);
            pair = ids(randperm(numel(ids), 2));
            id_1 = pair(1);
            id_2 = pair(2);

            if abs(p(i)) >= 0.5
                % 探索阶段
                if rand < 0.5
                    i_prev = i - 1;
                    if i_prev < 1
                        i_prev = pop;       
                    end
                    Xnew = k * rand() + 2 * Positions(i,:) - Positions(i_prev,:);
                else
                    Xnew = Best_X - 0.1 * Z + rand() * ((ub - lb) * rand() + lb);
                end
            else
                Psi_i = Psai(i,:);
                Psi_i(abs(Psi_i) < 1e-300) = 1e-300;

                add_1 = h * (Best_Psai - Worst_Psai) ...
                      + h2 * (Psai(id_1,:) - 2 * Psai(i,:) + Psai(id_2,:));
                add_2 = h * (Best_Psai - Worst_Psai) ...
                      + h2 * (Psai(id_1,:) + 2 * Psai(i,:) + Psai(id_2,:));

                pos_1 = Best_X + rand() * vc .* add_1 ./ Psi_i;
                pos_2 = Positions(i,:) + rand() * vc .* add_2 ./ Psi_i;

                mask = rand(1,dim) < 0.5;
                Xnew = pos_2;
                Xnew(mask) = pos_1(mask);
            end
        end

        
        Xnew = min(max(Xnew, lb), ub);

        Xnew_Cost = fobj(Xnew);
        if Cost(i) > Xnew_Cost
            Cost(i) = Xnew_Cost;
            Positions(i,:) = Xnew;
            if Cost(i) < Best_Cost
                Best_X    = Positions(i,:);
                Best_Cost = Cost(i);
            end
        end
        if Cost(i) > Worst_Cost
            Worst_Cost = Cost(i);
        end

        % 更新波函数
        Psai(i,:) = sin(rand() * Positions(i,:));
    end

    Iter_curve(l) = Best_Cost;
end

Best_fitness = Best_Cost;
Best_pos     = Best_X;

end

function step = Levy(dim)
beta  = 1.5;
sigma = (gamma(1 + beta) * sin(pi * beta / 2) / ...
        (gamma((1 + beta) / 2) * beta * 2 ^ ((beta - 1) / 2))) ^ (1 / beta);
u = 0.01 * randn(1, dim) * sigma;
v = randn(1, dim);
step = u ./ (abs(v) .^ (1 / beta));
end
