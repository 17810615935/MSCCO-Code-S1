%% 场景、模型参数、ALNS任务分配与路径规划问题
function [model, problem, scene, assignment] = SetupScenario(scenario_id, verbose, saved_assignment)

    if nargin < 2
        verbose = true;
    end

    %% 城市地图参数
    model.MAPSIZE_X = 500;
    model.MAPSIZE_Y = 500;
    model.MAPSIZE_Z = 100;
    model.Hmin = 20;
    model.Hmax_fly = 95;

    %% 无人机与约束参数
    model.D = 1;
    model.S = 5;
    model.theta_max = 60 * pi / 180;
    model.gamma_max = 45 * pi / 180;
    model.v = 10;
    model.depart_gap = 3;
    model.Nt = 100;
    model.Rc = 300;
    model.comm_ratio = 0.2;

    %% 代价权重
    model.wL = 0.30;
    model.wH = 0.10;
    model.wS = 0.30;
    model.wD = 0.30;
    model.w_UAV = 1.0;
    model.gamma_s = 1.0;
    model.gamma_c = 0.01;
    model.M_pen = 100;

    %% 场景配置
    switch scenario_id
        case 1
            [num_uavs, dc, warehouses, delivery_points, nfz, em, weather] = Scenario1();
        case 2
            [num_uavs, dc, warehouses, delivery_points, nfz, em, weather] = Scenario2();
        case 3
            [num_uavs, dc, warehouses, delivery_points, nfz, em, weather] = Scenario3();
        case 4
            [num_uavs, dc, warehouses, delivery_points, nfz, em, weather] = Scenario4();
        otherwise
            error('scenario_id必须为1-4。');
    end

    model.num_uavs = num_uavs;
    model.buildings = GenerateCityMap(model);
    model.no_fly_zones = nfz;
    model.em_zones = em;
    model.weather_zones = weather;

    delta_s = model.D + model.S;
    b = model.buildings;
    model.box_min = [b(:, 1) - delta_s, b(:, 2) - delta_s, -ones(size(b, 1), 1)];
    model.box_max = [b(:, 1) + b(:, 3) + delta_s, b(:, 2) + b(:, 4) + delta_s, b(:, 5) + delta_s];

    num_pairs = num_uavs * (num_uavs - 1) / 2;
    model.Nc_max = round(model.comm_ratio * num_pairs * (model.Nt + 1));

    %% ALNS任务分配
    alns.maxIter = 1000;
    alns.segment = 50;
    alns.reaction = 0.2;
    alns.sigma = [33, 9, 13];
    alns.start_ratio = 0.05;
    alns.end_ratio = 0.001;
    alns.remove_ratio = 0.4;
    alns.p_worst = 3;
    alns.p_shaw = 4;
    alns.balance_weight = 0.5;
    alns.threat_factor = 0.8;
    alns.min_cap = 1;

    if nargin >= 3 && ~isempty(saved_assignment)
        % 重绘时沿用实验保存的任务分配，不重新运行 ALNS。
        assignment = saved_assignment;
    else
        [assignment, alns_curve] = ALNS_TaskAllocation(model, dc, warehouses, ...
            delivery_points, num_uavs, alns);
        assignment.curve = alns_curve;
    end

    waypoints = cell(num_uavs, 1);
    assignment.text = cell(num_uavs, 1);
    for uav = 1:num_uavs
        route = assignment.routes{uav};
        pts = dc.position;
        for j = 1:numel(route)
            pts = [pts; warehouses(route(j)).position];
        end
        pts = [pts; delivery_points(assignment.ends(uav)).position];
        waypoints{uav} = pts;

        names = [{'DC'}, arrayfun(@(k) sprintf('W%d', k), route, 'UniformOutput', false), ...
            {sprintf('D%d', assignment.ends(uav))}];
        assignment.text{uav} = strjoin(names, ' -> ');
        if verbose
            fprintf('  UAV%d: %s  (%.1f m)\n', uav, assignment.text{uav}, assignment.route_length(uav));
        end
    end
    if verbose
        fprintf('  ALNS目标值: %.2f\n', assignment.cost);
    end

    %% 路径规划问题
    plan.node_spacing = 100;
    plan.min_nodes = 2;
    plan.max_nodes = 5;
    plan.sample_spacing = 15;
    plan.min_samples = 12;
    plan.margin = 100;
    plan.along_jitter = 1.5;
    problem = BuildPlanningProblem(model, waypoints, plan);

    scene.distribution_center = dc;
    scene.warehouses = warehouses;
    scene.delivery_points = delivery_points;
end
