function best_runs = ExportAlgorithmPaths(model, problem, scene, assignment, sid, algorithm_list, fit, pos, result_dir)
% 每个算法按自身最小评价代价选取一次运行，使用相同场景与任务分配绘图
num_alg = numel(algorithm_list);
assert(isequal(size(fit), size(pos)) && size(fit,2) == num_alg, ...
    '路径位置、适应度矩阵及算法列表尺寸不一致。');
if ~exist(result_dir, 'dir')
    mkdir(result_dir);
end
[best_values, best_runs] = min(fit, [], 1);
path_info = cell(1, num_alg);
path_values = zeros(1, num_alg);
consistent = false(1, num_alg);
for a = 1:num_alg
    assert(isfinite(best_values(a)), '算法 %s 没有有限的实验结果。', algorithm_list{a});
    bp = pos{best_runs(a), a};
    assert(numel(bp) == problem.dim, '算法 %s 的保存位置维度与场景不一致。', algorithm_list{a});
    [value, path_info{a}] = CalculateTotalCost(bp, problem, model);
    assert(isfinite(value), '算法 %s 的保存位置无法计算有限路径代价。', algorithm_list{a});
    path_values(a) = value;
    consistent(a) = abs(value-best_values(a)) <= 1e-8*max(1,abs(best_values(a)));
    if ~consistent(a)
        warning('PathPlot:CostMismatch', ...
            '场景%d %s：记录代价 %.12g，保存路径重算代价 %.12g。图中显示重算代价。', ...
            sid, algorithm_list{a}, best_values(a), value);
    end
end

% 先核对全部路径，再输出图像
manifest = sprintf('# 场景%d 路径图\n\n各算法采用自身最低评价代价对应的运行；不可行路径在图中明确标注。\n\n', sid);
manifest = [manifest, '按记录代价选取运行编号，图中代价与可行性根据保存的位置重算；两者不一致时明确标记，不替换原始统计数据。', newline, newline, ...
    '| 算法 | 运行编号 | 记录代价 | 路径重算代价 | 代价一致 | 总航程(m) | 可行 | 图像 |', newline, ...
    '| --- | ---: | ---: | ---: | --- | ---: | --- | --- |', newline];
for a = 1:num_alg
    draw_alns = a == num_alg;
    [fig_path, fig_alns] = PlotResults(model, scene.distribution_center, scene.warehouses, ...
        scene.delivery_points, path_info{a}, assignment, sid, algorithm_list{a}, draw_alns);
    fig_cleanup = onCleanup(@() close_figures(fig_path, fig_alns));
    match_status = '是';
    if ~consistent(a)
        match_status = '否';
        sgtitle(fig_path, sprintf('Saved position: recorded J=%.4g, recomputed J=%.4g', ...
            best_values(a), path_values(a)), 'FontSize', 12, 'FontWeight', 'normal');
    end
    filename = sprintf('场景%d_%s路径.png', sid, algorithm_list{a});
    exportgraphics(fig_path, fullfile(result_dir, filename), 'Resolution', 300);
    if draw_alns
        exportgraphics(fig_alns, fullfile(result_dir, sprintf('场景%d_ALNS收敛.png', sid)), 'Resolution', 300);
    end
    total_len = sum(cellfun(@(d) d.length, path_info{a}.uav_detail));
    status = '否';
    if path_info{a}.feasible
        status = '是';
    end
    manifest = [manifest, sprintf('| %s | %d | %.12g | %.12g | %s | %.6f | %s | [%s](%s) |\n', ...
        algorithm_list{a}, best_runs(a), best_values(a), path_values(a), match_status, total_len, status, filename, filename)]; %#ok<AGROW>
    fprintf('场景%d %-6s 路径图：运行%d，代价=%.6g，可行=%d\n', ...
        sid, algorithm_list{a}, best_runs(a), best_values(a), path_info{a}.feasible);
    clear fig_cleanup
end
fid = fopen(fullfile(result_dir, sprintf('场景%d_路径图说明.md', sid)), 'w', 'n', 'UTF-8');
assert(fid >= 0, '无法创建路径图说明文件。');
file_cleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid, '%s', manifest);
end

function close_figures(fig_path, fig_alns)
if isgraphics(fig_path)
    close(fig_path);
end
if isgraphics(fig_alns)
    close(fig_alns);
end
end
