%% 路径规划结果可视化
function [fig_path, fig_alns] = PlotResults(model, distribution_center, warehouses, delivery_points, info, assignment, scenario_id, algorithm, draw_alns)

    if nargin < 9
        draw_alns = true;
    end
    fig_alns = [];

    uav_colors = [
        166, 64,  54;
        53,  78,  107;
        229, 168, 75;
        93,  163, 157;
        120, 80,  160;
        60,  140, 60;
    ] / 255;

    traj = info.trajectories;
    buildings = model.buildings;
    max_h = max(buildings(:, 5));

    fig_path = figure('Name', sprintf('Scenario %d - %s', scenario_id, algorithm), ...
        'Position', [40, 40, 1620, 760], 'Color', 'w');

    % Equal square axes: same pixel size, same vertical position
    ax_side = 500;
    fig_pos = get(fig_path, 'Position');
    ax_w = ax_side / fig_pos(3);
    ax_h = ax_side / fig_pos(4);
    ax_y = 0.12;
    pos1 = [0.090, ax_y, ax_w, ax_h];
    pos2 = [0.575, ax_y, ax_w, ax_h];

    %% 3D视图
    ax1 = axes('Parent', fig_path, 'Position', pos1);
    hold on;
    for i = 1:size(buildings, 1)
        DrawBuilding3D(buildings(i, :), max_h, i == 1);
    end
    DrawEMThreatZones3D(model.no_fly_zones, model.em_zones, ...
        model.weather_zones, model.MAPSIZE_Z);
    DrawTaskPoints3D(distribution_center, warehouses, delivery_points);

    for uav = 1:numel(traj)
        c = uav_colors(mod(uav-1, size(uav_colors, 1)) + 1, :);
        P = traj{uav};
        plot3(P(:, 1), P(:, 2), P(:, 3), '-', 'Color', c, 'LineWidth', 2.4, ...
            'DisplayName', sprintf('UAV %d (%.0f m)', uav, info.uav_detail{uav}.length));
    end

    xlabel('X (m)', 'FontSize', 11);
    ylabel('Y (m)', 'FontSize', 11);
    zlabel('Height (m)', 'FontSize', 11);
    xlim([0, model.MAPSIZE_X]);
    ylim([0, model.MAPSIZE_Y]);
    zlim([0, model.MAPSIZE_Z]);
    xticks(0:100:500);
    yticks(0:100:500);
    zticks(0:20:100);
    view(-37.5, 24);
    pbaspect([1, 1, 0.56]);
    camzoom(1.12);
    grid on;
    box on;
    set(ax1, 'Color', [0.93, 0.95, 0.97], 'FontSize', 9, ...
        'GridAlpha', 0.16, 'GridColor', [0.45, 0.45, 0.45], ...
        'LineWidth', 0.7, 'Projection', 'perspective', 'SortMethod', 'childorder');
    title(sprintf('Scenario %d - %s (3D View)', scenario_id, algorithm), ...
        'FontSize', 13, 'FontWeight', 'normal');
    camlight('headlight');
    lighting gouraud;
    hold off;

    %% 俯视图
    ax2 = axes('Parent', fig_path, 'Position', pos2);
    hold on;
    for i = 1:size(buildings, 1)
        b = buildings(i, :);
        c = b(5) / max_h;
        rectangle('Position', b(1:4), ...
            'FaceColor', [0.34 + 0.08*c, 0.72 + 0.08*c, 0.82 + 0.06*c], ...
            'EdgeColor', [0.18, 0.48, 0.54], 'LineWidth', 0.6);
    end

    th = linspace(0, 2*pi, 60);
    for k = 1:size(model.weather_zones, 1)
        z = model.weather_zones(k, :);
        fill(z(1) + z(3)*cos(th), z(2) + z(3)*sin(th), [0.10, 0.24, 0.72], ...
            'FaceAlpha', 0.25, 'EdgeColor', [0.10, 0.24, 0.72], 'LineStyle', '--');
    end
    for k = 1:size(model.em_zones, 1)
        z = model.em_zones(k, :);
        fill(z(1) + z(3)*cos(th), z(2) + z(3)*sin(th), [0.52, 0.27, 0.20], ...
            'FaceAlpha', 0.30, 'EdgeColor', [0.52, 0.27, 0.20], 'LineStyle', '--');
    end
    for k = 1:size(model.no_fly_zones, 1)
        z = model.no_fly_zones(k, :);
        fill(z(1) + z(4)*cos(th), z(2) + z(4)*sin(th), [0.84, 0.25, 0.21], ...
            'FaceAlpha', 0.35, 'EdgeColor', [0.84, 0.25, 0.21]);
    end

    for uav = 1:numel(traj)
        c = uav_colors(mod(uav-1, size(uav_colors, 1)) + 1, :);
        P = traj{uav};
        plot(P(:, 1), P(:, 2), '-', 'Color', c, 'LineWidth', 2.2);
    end

    p = distribution_center.position;
    plot(p(1), p(2), 'p', 'MarkerSize', 15, ...
        'MarkerFaceColor', [0.95, 0.05, 0.05], 'MarkerEdgeColor', [0.55, 0, 0]);
    for i = 1:numel(warehouses)
        p = warehouses(i).position;
        plot(p(1), p(2), 's', 'MarkerSize', 7, ...
            'MarkerFaceColor', [0.95, 0.50, 0.12], 'MarkerEdgeColor', [0.48, 0.22, 0.04]);
        text(p(1)+5, p(2)+5, sprintf('W%d', i), 'FontSize', 7);
    end
    for i = 1:numel(delivery_points)
        p = delivery_points(i).position;
        plot(p(1), p(2), '^', 'MarkerSize', 8, ...
            'MarkerFaceColor', [0.25, 0.35, 0.85], 'MarkerEdgeColor', [0.08, 0.13, 0.42]);
        text(p(1)+5, p(2)+5, sprintf('D%d', i), 'FontSize', 7);
    end

    xlabel('X (m)', 'FontSize', 11);
    ylabel('Y (m)', 'FontSize', 11);
    xlim([0, model.MAPSIZE_X]);
    ylim([0, model.MAPSIZE_Y]);
    xticks(0:100:500);
    yticks(0:100:500);
    axis equal;
    axis([0, model.MAPSIZE_X, 0, model.MAPSIZE_Y]);
    grid on;
    box on;
    set(ax2, 'Color', [0.97, 0.98, 0.99], 'FontSize', 9, 'GridAlpha', 0.16);
    if info.feasible
        status = 'Feasible';
    else
        status = 'Infeasible';
    end
    title(sprintf('%s - Top View (J=%.4g, %s)', algorithm, info.J_eval, status), ...
        'FontSize', 13, 'FontWeight', 'normal', 'Interpreter', 'none');
    hold off;
    drawnow;
    ax1.Position = pos1;
    ax2.Position = pos2;
    lgd = legend(ax1, 'Location', 'northeast', 'FontSize', 8, 'Box', 'on');
    place_legend_in_gap(lgd, pos1, pos2);

    %% 任务分配与收敛曲线
    if ~draw_alns
        return;
    end
    fig_alns = figure('Name', 'ALNS Task Allocation', 'Position', [120, 120, 620, 440], 'Color', 'w');
    plot(assignment.curve, 'LineWidth', 1.6, 'Color', [0.00, 0.45, 0.74]);
    xlabel('Iteration');
    ylabel('Objective');
    title(sprintf('ALNS Task Allocation - Scenario %d', scenario_id), 'FontWeight', 'normal');
    grid on;
    box on;
end

function place_legend_in_gap(lgd, pos_left, pos_right)
    if ~isgraphics(lgd)
        return;
    end
    lgd.Units = 'normalized';
    lp = lgd.Position;
    gap_left = pos_left(1) + pos_left(3) + 0.010;
    gap_right = pos_right(1) - 0.008;
    w = min(lp(3), max(0.08, gap_right - gap_left));
    top = pos_left(2) + pos_left(4) - 0.010;
    bot = top - lp(4);
    if bot < pos_left(2)
        bot = pos_left(2);
    end
    lgd.Position = [gap_left, bot, w, lp(4)];
end
