%% 构建路径规划优化问题
function problem = BuildPlanningProblem(model, waypoints, params)

    num_uavs = numel(waypoints);
    lb = [];
    ub = [];
    seg = cell(num_uavs, 1);
    cursor = 0;

    for uav = 1:num_uavs
        wp = waypoints{uav};
        num_seg = size(wp, 1) - 1;
        seg{uav} = cell(num_seg, 1);

        for s = 1:num_seg
            p1 = wp(s, 1:2);
            p2 = wp(s+1, 1:2);
            chord = p2 - p1;
            len = norm(chord);
            if len > eps
                nrm = [-chord(2), chord(1)] / len;
            else
                nrm = [1, 0];
            end

            q = min(params.max_nodes, max(params.min_nodes, ceil(len / params.node_spacing)));
            ns = max(params.min_samples, ceil(len / params.sample_spacing));
            jitter = params.along_jitter / (q + 1);

            lb = [lb, repmat([-jitter, -params.margin, model.Hmin], 1, q)];
            ub = [ub, repmat([jitter, params.margin, model.Hmax_fly], 1, q)];

            seg{uav}{s} = struct('idx', cursor + (1:3*q), 'q', q, ...
                't', (1:q)' / (q + 1), 'p1', p1, 'chord', chord, 'normal', nrm, ...
                'basis', BSplineBasis(q + 2, 3, ns));
            cursor = cursor + 3*q;
        end
    end

    problem.waypoints = waypoints;
    problem.num_uavs = num_uavs;
    problem.seg = seg;
    problem.map = [model.MAPSIZE_X, model.MAPSIZE_Y];
    problem.lb = lb;
    problem.ub = ub;
    problem.dim = cursor;
end
