%% 解码控制点并生成B样条轨迹
function [trajectories, task_flags, ctrl_points] = DecodeSolution(x, problem)

    x = x(:)';
    num_uavs = problem.num_uavs;
    trajectories = cell(num_uavs, 1);
    task_flags = cell(num_uavs, 1);
    ctrl_points = cell(num_uavs, 1);

    for uav = 1:num_uavs
        wp = problem.waypoints{uav};
        num_seg = size(wp, 1) - 1;
        traj = wp(1, :);
        flag = true;
        ctrl = wp(1, :);

        for s = 1:num_seg
            g = problem.seg{uav}{s};
            V = reshape(x(g.idx), 3, g.q)';
            xy = g.p1 + (g.t + V(:, 1)) .* g.chord + V(:, 2) .* g.normal;
            xy = min(max(xy, 0), problem.map);
            P = [xy, V(:, 3)];
            C = [wp(s, :); P; wp(s+1, :)];
            curve = g.basis * C;
            curve(1, :) = wp(s, :);
            curve(end, :) = wp(s+1, :);

            traj = [traj; curve(2:end, :)];
            flag = [flag; false(size(curve, 1) - 2, 1); true];
            ctrl = [ctrl; P; wp(s+1, :)];
        end

        trajectories{uav} = traj;
        task_flags{uav} = flag;
        ctrl_points{uav} = ctrl;
    end
end
