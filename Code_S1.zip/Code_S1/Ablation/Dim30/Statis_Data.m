function [Best_val, Worst_val, Mean_val, Median_val, Std_val, Wilcoxon_RankSum_Test, Wilcoxon_SignedRank_Test, Friedamn_val] = Statis_Data(result, Func_name, num, RGBData)
close all

% Get the length of the result data (number of different experiments)
len = length(result.name);
[k, maxIter] = size(result.data{1});  % Extract the dimensions of the data (rows and columns)
data = zeros(len, k);  % Initialize matrix to store data

% Extract the last column from each dataset and store it in the data matrix
for i = 1:len
    mat = result.data{i};  
    data(i, :) = mat(:, end)';  % Store the last column of each result
end

% Initialize arrays for statistical measures
Best_val = zeros(1, len);    % Best (minimum) values
Worst_val = zeros(1, len);   % Worst (maximum) values
Mean_val = zeros(1, len);    % Mean values
Median_val = zeros(1, len);  % Median values
Std_val = zeros(1, len);     % Standard deviation values

% Calculate statistical values for each experiment
for i = 1:len
    Best_val(i) = min(data(i, :));        % Best value (minimum)
    Worst_val(i) = max(data(i, :));       % Worst value (maximum)
    Mean_val(i) = mean(data(i, :));       % Mean value
    Median_val(i) = median(data(i, :));   % Median value
    Std_val(i) = std(data(i, :));         % Standard deviation
end

%-----Wilcoxon Rank-Sum Test
Wilcoxon_RankSum_Test = [];
for i = 1:len
    if i == num
        continue;
    end
    [p, h] = ranksum(data(num, :), data(i, :));  % Perform the rank-sum test between data(num, :) and data(i, :)
    Wilcoxon_RankSum_Test = [Wilcoxon_RankSum_Test; [p, h]];  % Store the p-value and result
end

%-----Wilcoxon Signed-Rank Test
Wilcoxon_SignedRank_Test = [];
for i = 1:len
    if i == num
        continue;
    end
    [p, h] = signrank(data(num, :), data(i, :));  % Perform the signed-rank test between data(num, :) and data(i, :)
    Wilcoxon_SignedRank_Test = [Wilcoxon_SignedRank_Test; [p, h]];  % Store the p-value and result
end

%-----Friedman Test
[p, tbl, stats] = friedman(data');  % Perform the Friedman test across the data
Friedamn_val = stats.meanranks;    % Extract the mean ranks from the Friedman test results

%-----Save the generated images to the 'result' folder
if ~exist('result', 'dir')
    mkdir('result');  % Create the result folder if it doesn't exist
end

%-----Create a box plot (IEEE style)
figure('Color', 'w', 'Position', [100 100 560 420]);
box_color = RGBData(1:len, :);
boxplot(data', 'Colors', box_color, 'Symbol', 'k+', 'Widths', 0.6);

boxobj = findobj(gca, 'Tag', 'Box');
for j = 1:len
    patch(get(boxobj(j), 'XData'), get(boxobj(j), 'YData'), ...
        RGBData(len - j + 1, :), 'FaceAlpha', 0.5, 'EdgeColor', 'none');
end

set(findobj(gca, 'Type', 'Line'), 'LineWidth', 1.2);

xticks(1:len);
xticklabels(result.name);
xlabel('Algorithm', 'FontName', 'Times New Roman', 'FontSize', 12);
ylabel('Fitness Value', 'FontName', 'Times New Roman', 'FontSize', 12);
title(Func_name, 'FontName', 'Times New Roman', 'FontSize', 12, 'Interpreter', 'none');
set(gca, 'FontName', 'Times New Roman', 'FontSize', 10, ...
    'TickLabelInterpreter', 'none', 'LineWidth', 1.0, 'Box', 'on', ...
    'YGrid', 'on', 'GridLineStyle', ':', 'GridAlpha', 0.3);

boxplot_filename = fullfile('result', [Func_name '_boxplot.png']);
saveas(gcf, boxplot_filename);
end
