%% 无人机群协同总代价
function [J_eval, info] = CalculateTotalCost(x, problem, model)

    [traj, flags] = DecodeSolution(x, problem);
    num_uavs = problem.num_uavs;

    J_UAV = 0;
    penalty = 0;
    viol_geometry = 0;
    viol_safety = 0;
    viol_kinematic = 0;
    viol_building = 0;
    viol_weather = 0;
    viol_em = 0;
    viol_nofly = 0;
    uav_detail = cell(num_uavs, 1);
    for uav = 1:num_uavs
        [Ji, detail] = EvaluateSingleUAVCost(traj{uav}, flags{uav}, model);
        J_UAV = J_UAV + Ji;
        penalty = penalty + detail.penalty;
        viol_geometry = viol_geometry + detail.viol_geometry;
        viol_safety = viol_safety + detail.viol_safety;
        viol_kinematic = viol_kinematic + detail.viol_kinematic;
        viol_building = viol_building + detail.viol_B;
        viol_weather = viol_weather + detail.viol_weather;
        viol_em = viol_em + detail.viol_em;
        viol_nofly = viol_nofly + detail.viol_nofly;
        uav_detail{uav} = detail;
    end

    [J_space, J_comm, viol_space, N_off] = SwarmCost(traj, model);
    penalty = penalty + viol_space;
    viol_safety = viol_safety + viol_space;
    viol_hard = viol_geometry + viol_safety + viol_kinematic;

    J_total = model.w_UAV * J_UAV + J_space + J_comm;
    J_eval = J_total + model.M_pen * penalty;

    if nargout > 1
        info.trajectories = traj;
        info.task_flags = flags;
        info.uav_detail = uav_detail;
        info.J_UAV = J_UAV;
        info.J_space = J_space;
        info.J_comm = J_comm;
        info.N_off = N_off;
        info.viol_space = viol_space;
        info.viol_geometry = viol_geometry;
        info.viol_safety = viol_safety;
        info.viol_kinematic = viol_kinematic;
        info.viol_building = viol_building;
        info.viol_weather = viol_weather;
        info.viol_em = viol_em;
        info.viol_nofly = viol_nofly;
        info.viol_hard = viol_hard;
        info.violations = viol_hard;
        info.J_total = J_total;
        info.J_eval = J_eval;
        info.feasible = viol_hard == 0;
    end
end

function [J_space, J_comm, viol, N_off] = SwarmCost(traj, model)

    num_uavs = numel(traj);
    J_space = 0;
    J_comm = 0;
    viol = 0;
    N_off = 0;
    if num_uavs < 2
        return;
    end

    s = cell(num_uavs, 1);
    T_end = zeros(num_uavs, 1);
    for uav = 1:num_uavs
        P = traj{uav};
        d = [0; cumsum(sqrt(sum(diff(P, 1, 1).^2, 2)))];
        keep = [true; diff(d) > 0];
        s{uav} = struct('d', d(keep), 'P', P(keep, :));
        d = d(keep);
        T_end(uav) = (uav - 1) * model.depart_gap + d(end) / model.v;
    end

    t = linspace(0, max(T_end), model.Nt + 1)';
    pos = zeros(numel(t), 3, num_uavs);
    active = false(numel(t), num_uavs);
    for uav = 1:num_uavs
        t0 = (uav - 1) * model.depart_gap;
        dist = min(max((t - t0) * model.v, 0), s{uav}.d(end));
        if numel(s{uav}.d) > 1
            d = s{uav}.d;
            P = s{uav}.P;
            idx = min(sum(dist >= d', 2), numel(d) - 1);
            w = (dist - d(idx)) ./ (d(idx+1) - d(idx));
            pos(:, :, uav) = P(idx, :) + w .* (P(idx+1, :) - P(idx, :));
        else
            pos(:, :, uav) = repmat(s{uav}.P, numel(t), 1);
        end
        active(:, uav) = t > t0 & t < T_end(uav);
    end

    for a = 1:num_uavs-1
        for b = a+1:num_uavs
            both = active(:, a) & active(:, b);
            if ~any(both)
                continue;
            end
            dab = sqrt(sum((pos(both, :, a) - pos(both, :, b)).^2, 2));
            viol = viol + sum(dab < 2*model.D);
            band = dab >= 2*model.D & dab <= 2*model.D + model.S;
            J_space = J_space + sum(1 - (dab(band) - 2*model.D) / model.S);
            N_off = N_off + sum(dab > model.Rc);
        end
    end

    J_space = model.gamma_s * J_space;
    J_comm = model.gamma_c * max(0, N_off - model.Nc_max);
end
